# Implementation plan: agentic development environment

Status: draft v2.1, 2026-11-02. Decisions are in `agentic-dev-env-decisions.md`. Effort is given as S / M / L (relative), to be refined.

**Progress:** Phase 1 and Phase 2 deliverables exist as `dev-env-kit` **v0.1.1** (zip delivered to the owner). First run on the company laptop found a PowerShell parse error in `windows/01-prereqs.ps1` (`"$build: ..."` read as a drive-qualified variable); fixed in 0.1.1, which also hardens error handling of native commands for Windows PowerShell 5.1. The Windows scripts now parse with the real PowerShell parser and run end to end against a fake `wsl.exe` with mocked cmdlets. **Still pending: validation on the company Windows laptop** (kit `docs/VALIDATION-CHECKLIST.md`). Phase 0 and the pilot are next.

## 1. Goal and constraints

- Windows 11 Pro laptops, one WSL2 Ubuntu per laptop, VS Code connected to WSL, Copilot CLI sessions with worktree isolation.
- Installation must be simple and complete for developers of different levels: one manual, idempotent scripts, a self-check.
- Compliance: only company-approved tools (VS Code, Copilot, codegraph, Ikaro) plus context7 and the listed CLIs. Human review at every gate.
- Stack to maintain: OpenJDK 1.8, Maven 3.3.3, OpenText WEM and Portal 16.7, 50+ client repos on GitLab (branches `DEVELOPMENT` and `MASTER` exist in all of them).

## 2. Target architecture

```
Windows 11 Pro
  VS Code (Remote - WSL, Copilot, Copilot Chat)  --connects to-->  WSL2 Ubuntu (user: developer)
                                                                    Copilot CLI, codegraph, Ikaro, context7, OpenSpec
                                                                    JDK 8, Maven 3.3.3, git, gh, glab, markitdown, pandoc, TeX Live
                                                                    git hooks (system-wide): DEVELOPMENT / MASTER protected
~/code/BACKLOG (company GitHub) ── repos/ (client GitLab clones, git-ignored) ── workspaces/ ── shared/
~/docs/KNOWLEDGE-BASE (company GitHub): documents + Ikaro index
```

## 3. Phases

### Phase 0: preconditions (S) - to do
- GitHub organization: Copilot CLI and background agents allowed. Policy "MCP servers in Copilot" enabled; decide registry/allowlist so that codegraph, Ikaro, context7 and (later) Jira MCP are permitted.
- Laptops: virtualization enabled, rights to enable WSL, free disk space sized for clones + Maven repository + TeX Live.
- Create the private kit repository `dev-env-kit` on the company GitHub and fill in `config/kit.env`, `config/internal-tools.env` and `config/maven/settings.xml`.
- Jira: wait for the client's answer. The Jira MCP stays optional in the kit.

### Phase 1: installation kit (L) - built, v0.1.1, pending validation
Delivered as `dev-env-kit-0.1.1.zip`:

```
INSTALL-WINDOWS.cmd          double-click entry point
windows/01-prereqs.ps1       Windows/RAM/disk/virtualization checks, WSL install, .wslconfig, VS Code extensions, Copilot CLI remote-control setting
windows/02-wsl-ubuntu.ps1    Ubuntu-24.04 install (no wizard), kit copy with CRLF/exec-bit normalisation, user creation, provisioning
wsl/provision.sh             runs wsl/modules/* in order (idempotent)
wsl/modules/                 05-certs, 10-base, 20-java, 30-runtimes, 40-cli, 45-internal-tools, 50-agent
wsl/bin/                     dev-env, bk-clone-all, bk-sync, bk-new-branch, bk-workspace, bk-onboard-repo, bk-umbrella-new, bk-init-backlog
wsl/doctor.sh                self-check (platform, toolchain, agent tools, guardrails, config, connectivity, --deep Maven check)
git-hooks/                   pre-commit, pre-merge-commit, pre-push
config/ templates/ vendor/   configuration, BACKLOG skeleton + OpenSpec config, offline cache
docs/                        INSTALL, DAILY-USE, TROUBLESHOOTING, VALIDATION-CHECKLIST
tests/                       run-tests.sh (82 offline tests incl. PowerShell static checks), parse-ps.ps1
CHANGELOG.md                 version history
```

Design choices:
- Provision a fresh Ubuntu with scripts, rather than distributing a golden image: smaller, transparent, updatable by re-running (`dev-env update`). A golden image can be added later if installs prove fragile.
- Idempotent modules; versions in `versions.env` (`latest` until `dev-env freeze` output is pasted after validation).
- Repository list is `BACKLOG/repos.tsv` (tab separated: name, URL, notes) instead of YAML, to avoid a parser dependency.
- Offline fallback `vendor/` for downloads blocked by the corporate network; optional `config/certs/` for TLS-inspecting proxies.
- Company tools (codegraph, Ikaro, Jira MCP) are plugged in through `config/internal-tools.env` because their install commands are not known to the kit.
- Windows scripts use `$ErrorActionPreference = 'Continue'` plus explicit exit-code checks (Windows PowerShell 5.1 treats native stderr as terminating under 'Stop'), `WSL_UTF8=1`, and ASCII-only source.

### Phase 2: BACKLOG skeleton and helpers (M) - built inside the kit
- `templates/backlog-skeleton`: shared instructions, umbrella change template, `repos.tsv`, `.gitignore`, workspaces folder. Copied by `bk-init-backlog` (never overwrites).
- `bk-onboard-repo`: work branch from `origin/DEVELOPMENT`, `openspec init --tools none` (only `openspec/`), project context template, commit, optional push and merge request with `glab`. Run it the first time a repo is touched, not for 50 repos upfront.
- Still to do by the owner: commit the skeleton to BACKLOG, fill `repos.tsv`, load OpenText WEM and Portal 16.7 javadoc and PDFs into KNOWLEDGE-BASE (markitdown), index with Ikaro and publish the index.

### Phase 3: pilot (M) - to do
2 or 3 representative repos, 2 or 3 developers of different levels, at least one evolutive that touches two repos. The kit's `docs/VALIDATION-CHECKLIST.md` covers the first run on the company laptop; the table below is the functional pilot.

| # | Check | Pass criterion | Status |
|---|---|---|---|
| 1 | VS Code Copilot CLI session with worktree isolation | Runs inside WSL (Java 8 and Maven available in the session) | to verify |
| 2 | Worktree location and hooks | Folder is outside `BACKLOG/repos`; hooks active inside the worktree | to verify |
| 3 | Shared instructions | Loaded in CLI (`~/.copilot/copilot-instructions.md`) and in VS Code chat (`~/.copilot/instructions`) | CLI verified (Copilot CLI 1.0.105 lists it); VS Code to verify |
| 4 | OpenSpec skills at user level | Visible in CLI and VS Code; `openspec init --tools none` leaves only `openspec/` in the repo | CLI and `openspec init` verified; VS Code to verify |
| 5 | codegraph and Ikaro MCP | Work in CLI and VS Code (separate config files); Ikaro searches the remote index | CLI reads the generated file (verified with context7); company tools to verify |
| 6 | MCP policy | context7, codegraph, Ikaro not blocked by organization policy | to verify |
| 7 | Build | Both repos build with Maven 3.3.3 against Artifactory, also inside a worktree | to verify |
| 8 | Multi-root workspace | Chat searches across roots; behaviour of worktree isolation in multi-root is known | to verify |
| 9 | Hooks under agent control | Commit, merge and push to `DEVELOPMENT` / `MASTER` blocked, including from agent sessions | hooks verified in git; agent sessions to verify |
| 10 | Umbrella flow end to end | Analysis in BACKLOG, per-repo briefs, 2 repos implemented, MRs opened, manual deployment and test | to verify |
| 11 | Installation | Kit installs on 3 laptops of different level; doctor passes; time per install recorded | to verify |
| 12 | Cost | Copilot premium request consumption measured over a typical day | to verify |

Exit criteria: all checks pass or have a documented workaround; installation completed without help by the least experienced participant; the owner agrees the review effort is acceptable.

### Phase 4: team rollout (M)
- Half-day hands-on session using `DAILY-USE.md`; kit versioned with release notes (`CHANGELOG.md`) and an update command.
- Support channel and a feedback log; revise shared instructions weekly at first.
- Keep parallel sessions low at the start; enable more as the team gains confidence.

### Phase 5: incremental improvement (continuous)
- Specs, refactors and docs per repo as repos are touched; tests added incrementally (start with the code being changed).
- Automate the Ikaro index refresh (today a manual task of the owner).
- Later candidates: SSH access for deployment (with its own security review), SonarQube, a Jira module once the client confirms the edition.

## 4. Risks and mitigations

| Risk | Mitigation |
|---|---|
| Organization MCP policy blocks servers | Phase 0 policy review; check #6 in the pilot |
| Corporate proxy or TLS inspection breaks Maven, npm or Copilot | Doctor script with hints; `config/certs/` installs the CA in Ubuntu (feeds Java 8), Node and Python variables; `vendor/` offline cache |
| Windows scripts differ between Windows PowerShell 5.1 and the PowerShell used for tests (7.0.3) | Validation checklist runs them on the real laptop first; failures are fixed in the kit and recorded in `CHANGELOG.md` |
| Copilot CLI and VS Code agent features change quickly | Pin versions with `dev-env freeze`; controlled updates through the kit |
| Worktree sessions run without approvals | System hooks, shared instructions, read-only Jira and Artifactory, human review before any push |
| `glab` browser login may not be available on a self-managed GitLab | Personal access token fallback documented in TROUBLESHOOTING |
| Single maintainer of the knowledge base | Accepted now; automate refresh in Phase 5 |
| Legacy code without tests | Small applies, human review, manual test after deployment, tests added incrementally |
| OpenText APIs are poorly known to models | Ikaro index of javadoc and PDFs; shared instructions tell the agent to consult it first |
| Laptop resources (Maven, indexes, several sessions) | `.wslconfig` limits written by the installer; measure in pilot |
