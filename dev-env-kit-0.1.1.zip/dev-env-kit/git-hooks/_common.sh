#!/usr/bin/env bash
# Shared logic for the dev-env git hooks. Advisory guardrail only: --no-verify bypasses hooks.
#
# Protected branch pattern, first match wins:
#   1. environment variable PROTECTED_BRANCHES_REGEX
#   2. file /etc/dev-env/protected-branches (first line)
#   3. built-in default

protected_regex() {
  if [ -n "${PROTECTED_BRANCHES_REGEX:-}" ]; then
    printf '%s' "$PROTECTED_BRANCHES_REGEX"
  elif [ -s /etc/dev-env/protected-branches ]; then
    head -n1 /etc/dev-env/protected-branches
  else
    printf '%s' '^(DEVELOPMENT|MASTER)$'
  fi
}

is_protected() {
  local re
  re="$(protected_regex)"
  [[ "$1" =~ $re ]]
}

current_branch() {
  git symbolic-ref --short -q HEAD || true
}
