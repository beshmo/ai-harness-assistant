#!/usr/bin/env bash
# Offline tests for the kit's scripts (hooks, bk-* helpers, agent helpers). No root, no Windows needed.
# Usage: tests/run-tests.sh
# Requires: git, jq. The bk-onboard-repo test also needs the 'openspec' CLI (skipped if missing).
set -uo pipefail

KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

PASS=0; FAIL=0
t_ok()   { PASS=$((PASS + 1)); echo "  PASS  $*"; }
t_fail() { FAIL=$((FAIL + 1)); echo "  FAIL  $*"; }
expect_ok()   { local d="$1"; shift; if "$@" >"$WORK/out" 2>&1; then t_ok "$d"; else t_fail "$d"; sed 's/^/        /' "$WORK/out" | head -15; fi; }
expect_fail() { local d="$1"; shift; if "$@" >"$WORK/out" 2>&1; then t_fail "$d (expected failure)"; else t_ok "$d"; fi; }

# --- isolated environment (never touches the real HOME or /etc) ---------------------------------
export HOME="$WORK/home"; mkdir -p "$HOME"
export DEVENV_ROOT="$KIT"
DEV_USER="$(id -un)"
export DEV_USER DEV_HOME="$HOME"
export CODE_DIR="$WORK/code" DOCS_DIR="$WORK/docs"
export BACKLOG_DIR="$CODE_DIR/BACKLOG" REPOS_DIR="$CODE_DIR/BACKLOG/repos"
export KNOWLEDGE_BASE_DIR="$DOCS_DIR/KNOWLEDGE-BASE" WORKTREES_DIR="$CODE_DIR/worktrees"
export PATH="$KIT/wsl/bin:$PATH"
export GIT_CONFIG_GLOBAL="$WORK/gitconfig"
git config --global user.name "Test User"; git config --global user.email test@example.com
git config --global init.defaultBranch DEVELOPMENT
git config --global protocol.file.allow always
git config --global advice.detachedHead false

make_remote() { # name -> bare repo with DEVELOPMENT and MASTER
  local name="$1" bare="$WORK/remotes/$1.git" tmp
  mkdir -p "$WORK/remotes"; git init -q --bare "$bare"
  tmp="$(mktemp -d)"; git init -q "$tmp"; git -C "$tmp" checkout -q -b MASTER
  echo "$name" >"$tmp/README"; git -C "$tmp" add README; git -C "$tmp" -c core.hooksPath=/dev/null commit -qm init
  git -C "$tmp" branch DEVELOPMENT
  git -C "$tmp" -c core.hooksPath=/dev/null push -q "$bare" MASTER DEVELOPMENT
  git -C "$bare" symbolic-ref HEAD refs/heads/MASTER
  rm -rf "$tmp"; echo "$bare"
}

echo "== script syntax"
for f in "$KIT"/wsl/*.sh "$KIT"/wsl/lib/*.sh "$KIT"/wsl/modules/*.sh "$KIT"/wsl/bin/* "$KIT"/git-hooks/*; do
  expect_ok "bash -n ${f#"$KIT"/}" bash -n "$f"
done

echo "== PowerShell static checks (no PowerShell available here)"
for f in "$KIT"/windows/*.ps1; do
  # "$var:" inside a string is parsed as a drive-qualified variable in PowerShell; use "${var}:".
  if grep -nE '\$[A-Za-z_][A-Za-z0-9_]*:' "$f" | grep -vE '\$(env|script|global|private|local):' | grep -q .; then
    t_fail "${f#"$KIT"/}: contains \$var: (use \${var}:)"
  else
    t_ok "${f#"$KIT"/}: no \$var: hazards"
  fi
  if LC_ALL=C grep -nP '[^\x00-\x7F]' "$f" | grep -q .; then t_fail "${f#"$KIT"/}: non-ASCII characters"; else t_ok "${f#"$KIT"/}: ASCII only"; fi
  if command -v pwsh >/dev/null 2>&1; then
    expect_ok "${f#"$KIT"/}: parses with PowerShell" pwsh -NoProfile -File "$KIT/tests/parse-ps.ps1" "$f"
  fi
done

echo "== config"
expect_ok "kit.env, versions.env and internal-tools.env source cleanly" bash -c ". '$KIT/wsl/lib/common.sh' && load_config && [ -n \"\$BACKLOG_DIR\" ]"
expect_ok "default protected regex" bash -c ". '$KIT/git-hooks/_common.sh' && is_protected DEVELOPMENT && is_protected MASTER && ! is_protected feature/X-1"

echo "== git hooks (global core.hooksPath, protected: DEVELOPMENT, MASTER)"
git config --global core.hooksPath "$KIT/git-hooks"
R="$WORK/hooktest"; git init -q "$R"; cd "$R" || exit 1
echo a >a; git add a
expect_fail "commit on DEVELOPMENT is blocked" git commit -qm x
git -c core.hooksPath=/dev/null commit -qm init
git checkout -q -b feature/PROJ-1-x; echo b >b; git add b
expect_ok "commit on a feature branch is allowed" git commit -qm "PROJ-1: b"
git checkout -q DEVELOPMENT; echo c >c; git -c core.hooksPath=/dev/null add c; git -c core.hooksPath=/dev/null commit -qm diverge
expect_fail "merge commit on DEVELOPMENT is blocked" git merge --no-ff -m m feature/PROJ-1-x
git merge --abort 2>/dev/null || true; git reset -q --hard
git checkout -q -b MASTER; echo m >m; git add m
expect_fail "commit on MASTER is blocked" git commit -qm x
git reset -q --hard; git checkout -q feature/PROJ-1-x
git init -q --bare "$WORK/hook-remote.git"; git remote add origin "$WORK/hook-remote.git"
expect_fail "push to MASTER is blocked" git push -q origin feature/PROJ-1-x:MASTER
expect_fail "push to DEVELOPMENT is blocked" git push -q origin feature/PROJ-1-x:DEVELOPMENT
expect_ok "push to a feature branch is allowed" git push -q origin feature/PROJ-1-x
expect_fail "delete of protected remote branch is blocked" git push -q origin :DEVELOPMENT
PROTECTED_BRANCHES_REGEX='^(develop|main)$' expect_ok "env override changes the pattern (DEVELOPMENT allowed)" bash -c "git checkout -q DEVELOPMENT && echo z >z && git add z && git commit -qm z"
cd "$WORK" || exit 1

echo "== bk-clone-all / bk-sync"
mkdir -p "$BACKLOG_DIR"; git init -q "$BACKLOG_DIR"
A="$(make_remote repo-a)"; B="$(make_remote repo-b)"
printf '# comment\nrepo-a\t%s\tnotes a\nrepo-b\t%s\n' "$A" "$B" >"$BACKLOG_DIR/repos.tsv"
expect_ok "bk-clone-all clones every listed repo" bk-clone-all
[ "$(git -C "$REPOS_DIR/repo-a" branch --show-current)" = "DEVELOPMENT" ] && t_ok "cloned repo is on DEVELOPMENT" || t_fail "cloned repo is not on DEVELOPMENT"
expect_ok "bk-clone-all is idempotent" bk-clone-all
bad="$WORK/remotes/nobranch.git"; git init -q --bare "$bad"; t="$(mktemp -d)"; git init -q "$t"; git -C "$t" checkout -q -b MASTER; echo x >"$t/x"; git -C "$t" add x; git -C "$t" -c core.hooksPath=/dev/null commit -qm i; git -C "$t" -c core.hooksPath=/dev/null push -q "$bad" MASTER
printf 'repo-c\t%s\n' "$bad" >>"$BACKLOG_DIR/repos.tsv"
bk-clone-all repo-c >"$WORK/out" 2>&1; grep -q "DEVELOPMENT not found" "$WORK/out" && t_ok "missing DEVELOPMENT branch is reported" || { t_fail "missing branch not reported"; cat "$WORK/out"; }
# new commit on the remote, sync should fast-forward
t2="$(mktemp -d)"; git clone -q "$A" "$t2/a"; git -C "$t2/a" checkout -q DEVELOPMENT; echo new >"$t2/a/new"; git -C "$t2/a" add new; git -C "$t2/a" -c core.hooksPath=/dev/null commit -qm new; git -C "$t2/a" -c core.hooksPath=/dev/null push -q origin DEVELOPMENT
expect_ok "bk-sync runs" bk-sync repo-a repo-b
[ -f "$REPOS_DIR/repo-a/new" ] && t_ok "bk-sync fast-forwards a clean DEVELOPMENT checkout" || t_fail "bk-sync did not fast-forward"

echo "== bk-new-branch"
expect_ok "creates feature/PROJ-12-fix-login" bk-new-branch -r repo-a PROJ-12 fix-login
[ "$(git -C "$REPOS_DIR/repo-a" branch --show-current)" = "feature/PROJ-12-fix-login" ] && t_ok "branch name is feature/<KEY>-<slug>" || t_fail "wrong branch name"
git -C "$REPOS_DIR/repo-a" switch -q DEVELOPMENT
expect_ok "creates a worktree with -w" bk-new-branch -w -t fix -r repo-b PROJ-13 null-pointer
[ -d "$WORKTREES_DIR/repo-b/PROJ-13-null-pointer" ] && t_ok "worktree lives under WORKTREES_DIR" || t_fail "worktree missing"
expect_fail "rejects an invalid Jira key" bk-new-branch -r repo-a proj-1 x
expect_fail "rejects an invalid slug" bk-new-branch -r repo-a PROJ-14 "Bad Slug"
expect_fail "rejects an existing branch" bk-new-branch -r repo-a PROJ-12 fix-login
echo dirty >"$REPOS_DIR/repo-a/README"
expect_fail "refuses to switch branch with uncommitted changes" bk-new-branch -r repo-a PROJ-15 other
git -C "$REPOS_DIR/repo-a" checkout -q -- README

echo "== bk-workspace / bk-umbrella-new / bk-init-backlog"
mkdir -p "$KNOWLEDGE_BASE_DIR"
expect_ok "bk-workspace creates a workspace" bk-workspace PROJ-12 repo-a repo-b
jq -e '.folders | length == 4' "$BACKLOG_DIR/workspaces/PROJ-12.code-workspace" >/dev/null && t_ok "workspace has 4 roots (BACKLOG, 2 repos, KNOWLEDGE-BASE)" || t_fail "workspace roots wrong"
( cd "$BACKLOG_DIR/workspaces" && [ -d "$(jq -r '.folders[1].path' PROJ-12.code-workspace)/.git" ] ) && t_ok "relative paths resolve to the repos" || t_fail "relative paths broken"
expect_fail "bk-workspace refuses an uncloned repo" bk-workspace PROJ-12 nope
expect_ok "bk-init-backlog copies the skeleton" bk-init-backlog
[ -f "$BACKLOG_DIR/shared/instructions/general.instructions.md" ] && t_ok "shared instructions copied" || t_fail "shared instructions missing"
grep -qxF 'repos/' "$BACKLOG_DIR/.gitignore" && t_ok "repos/ is git-ignored" || t_fail "repos/ not ignored"
echo "custom" >"$BACKLOG_DIR/shared/instructions/general.instructions.md"
expect_ok "bk-init-backlog never overwrites" bk-init-backlog
[ "$(cat "$BACKLOG_DIR/shared/instructions/general.instructions.md")" = "custom" ] && t_ok "existing file preserved" || t_fail "file overwritten"
cp "$KIT/templates/backlog-skeleton/shared/instructions/general.instructions.md" "$BACKLOG_DIR/shared/instructions/general.instructions.md"
expect_ok "bk-umbrella-new creates an umbrella change" bk-umbrella-new PROJ-20 shared-lib-upgrade
grep -q "PROJ-20" "$BACKLOG_DIR/changes/PROJ-20-shared-lib-upgrade/plan.md" && ! grep -rq "@@KEY@@" "$BACKLOG_DIR/changes/PROJ-20-shared-lib-upgrade" && t_ok "placeholders replaced" || t_fail "placeholders left"
expect_fail "bk-umbrella-new refuses an existing change" bk-umbrella-new PROJ-20 shared-lib-upgrade

echo "== agent helpers (instructions, MCP, skills)"
# shellcheck disable=SC1091
. "$KIT/wsl/lib/common.sh"; . "$KIT/wsl/lib/agent.sh"; load_config
expect_ok "link_instructions" link_instructions
[ -f "$HOME/.copilot/copilot-instructions.md" ] && [ -d "$HOME/.copilot/instructions" ] && t_ok "instruction links resolve" || t_fail "instruction links broken"
CODEGRAPH_MCP_COMMAND=echo CODEGRAPH_MCP_ARGS_JSON='["hello","world"]' IKARO_MCP_COMMAND=ikaro IKARO_MCP_ENV_JSON='{"INDEX":"x"}' build_mcp_configs >/dev/null 2>&1
jq -e '.mcpServers | has("context7") and has("codegraph") and has("ikaro") and (has("jira")|not)' "$HOME/.copilot/mcp-config.json" >/dev/null && t_ok "Copilot CLI MCP file has context7, codegraph, ikaro (no jira)" || t_fail "CLI MCP content wrong"
jq -e '.mcpServers.codegraph | .type=="local" and .command=="echo" and .args==["hello","world"] and .tools==["*"]' "$HOME/.copilot/mcp-config.json" >/dev/null && t_ok "CLI entry format (type local, command, args, tools)" || t_fail "CLI entry format wrong"
jq -e '.servers.ikaro | .type=="stdio" and .env.INDEX=="x"' "$HOME/.vscode-server/data/User/mcp.json" >/dev/null && t_ok "VS Code MCP file format (servers, stdio, env)" || t_fail "VS Code MCP format wrong"
[ "$(stat -c %a "$HOME/.copilot/mcp-config.json")" = "600" ] && t_ok "MCP files are mode 600" || t_fail "MCP file mode"
jq '.mcpServers.custom = {"type":"local","command":"mine","args":[],"tools":["*"]}' "$HOME/.copilot/mcp-config.json" >"$WORK/m.json" && mv "$WORK/m.json" "$HOME/.copilot/mcp-config.json"
build_mcp_configs >/dev/null 2>&1
jq -e '.mcpServers.custom.command=="mine"' "$HOME/.copilot/mcp-config.json" >/dev/null && t_ok "user-added MCP servers are preserved on re-run" || t_fail "user MCP server lost"

if command -v openspec >/dev/null 2>&1; then
  echo "== OpenSpec integration"
  expect_ok "export_openspec_skills" export_openspec_skills
  n="$(find "$HOME/.copilot/skills" -maxdepth 1 -name 'openspec-*' -type d | wc -l)"
  [ "$n" -ge 4 ] && t_ok "OpenSpec skills installed at user level ($n)" || t_fail "skills missing ($n)"
  expect_ok "bk-onboard-repo adds openspec/ on a work branch" bk-onboard-repo repo-b
  [ "$(git -C "$REPOS_DIR/repo-b" branch --show-current)" = "chore/openspec-bootstrap" ] && t_ok "on branch chore/openspec-bootstrap" || t_fail "wrong branch"
  changed="$(git -C "$REPOS_DIR/repo-b" show --name-only --format= HEAD | sed 's#/.*##' | sort -u | tr '\n' ' ')"
  [ "$changed" = "openspec " ] && t_ok "commit touches only openspec/" || t_fail "commit touches: $changed"
  grep -q "Java 8 only" "$REPOS_DIR/repo-b/openspec/config.yaml" && t_ok "project context template applied" || t_fail "config.yaml template missing"
  ( cd "$REPOS_DIR/repo-b" && openspec list >/dev/null 2>&1 ) && t_ok "openspec accepts the generated config" || t_fail "openspec rejects the config"
  git -C "$REPOS_DIR/repo-b" push -q origin chore/openspec-bootstrap 2>/dev/null; git -C "$REPOS_DIR/repo-b" checkout -q DEVELOPMENT
  expect_fail "bk-onboard-repo refuses a branch that already exists" bk-onboard-repo repo-b
else
  echo "== OpenSpec integration: SKIPPED (openspec not installed)"
fi

echo
echo "Result: $PASS passed, $FAIL failed"
[ "$FAIL" -eq 0 ]
