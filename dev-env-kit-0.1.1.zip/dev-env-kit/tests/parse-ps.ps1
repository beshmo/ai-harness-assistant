# Parses PowerShell files with the real PowerShell parser and reports syntax errors.
# Usage: pwsh -NoProfile -File tests/parse-ps.ps1 <file.ps1>      (one file per call)
param([Parameter(Mandatory = $true)][string]$File)

$tokens = $null
$errors = $null
[void][System.Management.Automation.Language.Parser]::ParseFile($File, [ref]$tokens, [ref]$errors)
if ($errors.Count -eq 0) {
  Write-Output "PARSE OK    $File"
  exit 0
}
foreach ($e in $errors) {
  Write-Output ("PARSE ERROR {0} line {1}: {2}" -f $File, $e.Extent.StartLineNumber, $e.Message)
}
exit 1
