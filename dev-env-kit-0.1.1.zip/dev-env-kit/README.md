# dev-env kit

Installs and configures the agentic development environment on corporate Windows 11 laptops:
VS Code connected to WSL2 (Ubuntu 24.04), GitHub Copilot CLI, OpenSpec, context7, codegraph, Ikaro,
JDK 8, Maven 3.3.3, git guardrails and the helper commands used by the team.

Design decisions and rationale: see the project documents `agentic-dev-env-decisions.md` and
`implementation-plan.md` (Claude Project "Entorno de desarrollo con IA agentica").

## Quick start

1. **Maintainer, once:** fill in `config/kit.env`, `config/internal-tools.env`, copy the project's
   `settings.xml` to `config/maven/settings.xml`, and (if needed) add corporate certificates to `config/certs/`.
2. **Each laptop:** get this folder (git clone with Windows git, or the zip) in a simple path such as
   `C:\dev-env-kit`, then double-click **`INSTALL-WINDOWS.cmd`**.
3. **First use, inside Ubuntu:** `dev-env identity`, `dev-env login`, `dev-env setup-repos`, `dev-env doctor`.

The complete step-by-step manual is [`docs/INSTALL.md`](docs/INSTALL.md).

## What is installed

| Where | What |
|---|---|
| Windows | `.wslconfig` (memory/CPU limits), VS Code extensions (Remote - WSL, Copilot, Copilot Chat) |
| WSL (Ubuntu 24.04) | user `developer`, OpenJDK 8, Maven 3.3.3, Node.js, Python + pipx, git, gh, glab, Copilot CLI, OpenSpec, context7 MCP, markitdown, pandoc + TeX Live, tmux, wslu |
| Guardrails | system-wide git hooks that block commits, merges and pushes on `DEVELOPMENT` and `MASTER` |
| Agent setup | shared instructions (Copilot CLI and VS Code), MCP servers (CLI and VS Code), OpenSpec skills at user level |
| Layout | `~/code/BACKLOG` (+ `repos/`), `~/code/worktrees`, `~/docs/KNOWLEDGE-BASE` |

## Commands

| Command | Purpose |
|---|---|
| `dev-env doctor [--deep]` | Health check of the installation |
| `dev-env identity / login / setup-repos` | First-use steps |
| `dev-env update` | Pull the kit and re-run provisioning |
| `dev-env freeze` | Print installed versions (paste into `versions.env`) |
| `bk-clone-all`, `bk-sync` | Clone / update the client repositories listed in `BACKLOG/repos.tsv` |
| `bk-new-branch [-w] KEY slug` | Work branch (or worktree) `feature/<KEY>-<slug>` from `DEVELOPMENT` |
| `bk-onboard-repo repo` | Add the `openspec/` folder to a client repo (branch + optional MR) |
| `bk-umbrella-new KEY slug` | Cross-repository change in `BACKLOG/changes/` |
| `bk-workspace KEY repo...` | Multi-root `.code-workspace` for cross-repository questions |
| `bk-init-backlog` | Copy the BACKLOG skeleton (instructions, templates) |

Daily workflows: [`docs/DAILY-USE.md`](docs/DAILY-USE.md). Problems: [`docs/TROUBLESHOOTING.md`](docs/TROUBLESHOOTING.md).
**First run on the company laptop: follow [`docs/VALIDATION-CHECKLIST.md`](docs/VALIDATION-CHECKLIST.md).**

## Repository layout

```
INSTALL-WINDOWS.cmd        double-click entry point (runs the two PowerShell steps)
windows/                   01-prereqs.ps1 (WSL, .wslconfig, VS Code), 02-wsl-ubuntu.ps1 (distro, kit copy, provisioning)
wsl/provision.sh           runs wsl/modules/* in order (idempotent)
wsl/modules/               05-certs, 10-base, 20-java, 30-runtimes, 40-cli, 45-internal-tools, 50-agent
wsl/bin/                   dev-env and bk-* commands (linked into /usr/local/bin)
wsl/lib/                   shared shell helpers
wsl/doctor.sh              health check
git-hooks/                 pre-commit, pre-merge-commit, pre-push (installed system-wide)
config/                    kit.env, internal-tools.env, maven settings, certificates, VS Code extension lists
templates/                 BACKLOG skeleton and the OpenSpec project config
vendor/                    optional offline cache for blocked downloads
tests/run-tests.sh         offline test suite for the scripts
versions.env               tool versions
```

## Maintaining the kit

- Change versions in `versions.env`; run `dev-env freeze` on a validated laptop to pin them.
- Add a tool: create a numbered module in `wsl/modules/` (idempotent, `set -euo pipefail`, source `common.sh`).
- Run `tests/run-tests.sh` before publishing a new version (needs `git` and `jq`; `openspec` enables the OpenSpec tests).
- Keep line endings as LF (`.gitattributes` does it). The installer also normalises CRLF when copying into WSL.
- Never commit real secrets. The shared read-only Artifactory user in `settings.xml` is a project decision;
  keep the kit repository private.
