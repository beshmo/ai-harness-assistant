# Installation manual

Time needed: 30-60 minutes (mostly downloads). You can run the installer again at any time: it is idempotent.

## 0. Before you start

You need:
- Windows 11 Pro (build 22000 or newer), 16 GB RAM or more recommended, 60 GB free disk space.
- Virtualization enabled in the BIOS/UEFI (Intel VT-x / AMD-V).
- VS Code installed (from the company software catalog).
- Your company GitHub account with a Copilot seat, and your access to the client's GitLab.
- Permission to enable WSL. If WSL is not installed and you are not a local administrator, ask IT to run
  `wsl --install --no-distribution` **for your user** and restart the PC. Do not use a different admin account to run this kit:
  the Ubuntu distro is registered per Windows user.

## 1. Prepare the kit (maintainer, once per kit version)

Edit these files and commit them to the (private) kit repository:

| File | What to set |
|---|---|
| `config/kit.env` | Replace every `CHANGE_ME`: client GitLab host, BACKLOG / KNOWLEDGE-BASE / kit repository URLs, Artifactory URL |
| `config/maven/settings.xml` | Copy the project's common `settings.xml` here (the template shows the expected shape) |
| `config/internal-tools.env` | Install command and MCP command of codegraph and Ikaro (and Jira once known); empty = skipped |
| `config/certs/*.crt` | Only if the company network inspects TLS: corporate CA certificates (PEM) |
| `versions.env` | Optional: pin versions (`dev-env freeze` prints the current ones) |

## 2. Get the kit on the laptop

Use a short path without spaces or accents, for example `C:\dev-env-kit`.

- With git: `git clone <kit repository URL> C:\dev-env-kit`
- Or unzip the provided zip to `C:\dev-env-kit`.

Line endings are handled automatically (the repository forces LF and the installer converts CRLF if needed).

## 3. Run the Windows installer

Double-click **`INSTALL-WINDOWS.cmd`** (or run it from a terminal). It runs two steps:

1. `windows\01-prereqs.ps1` - checks Windows, RAM, disk and virtualization; installs WSL if missing (needs an
   elevated terminal and a restart the first time); writes `%UserProfile%\.wslconfig`; installs the VS Code
   extensions; makes sure the Copilot CLI remote-control setting is off.
2. `windows\02-wsl-ubuntu.ps1` - installs the `Ubuntu-24.04` distro without the first-run wizard, copies the kit
   to `/opt/dev-env`, creates the `developer` user, and provisions everything (JDK 8, Maven 3.3.3, Node.js, CLIs,
   hooks, instructions, MCP servers, OpenSpec skills). At the end it runs `dev-env doctor`.

If the installer asks for a restart, restart and double-click the file again.

When the network blocks the Microsoft/Ubuntu download, get an Ubuntu 24.04 `.wsl` image (or rootfs `.tar.gz`)
from IT and run:

```powershell
powershell -ExecutionPolicy Bypass -File windows\02-wsl-ubuntu.ps1 -FromFile C:\path\to\Ubuntu-24.04.wsl
```

When a download inside WSL is blocked (Maven, Node.js, glab), put the file in `vendor/` (see `vendor/README.md`) and
run the installer again.

## 4. First use (inside Ubuntu)

Open **Windows Terminal** and pick **Ubuntu-24.04** (or run `wsl -d Ubuntu-24.04`). You are the user `developer`.

```bash
dev-env identity            # your name and company e-mail for git
dev-env login               # GitHub, then GitLab (a browser opens on Windows)
copilot                     # start Copilot CLI once and type /login, then /exit
dev-env setup-repos         # clones BACKLOG and KNOWLEDGE-BASE, copies the BACKLOG skeleton
```

Then edit `~/code/BACKLOG/repos.tsv` (one client repository per line: name, TAB, URL, TAB, notes), and:

```bash
bk-clone-all                # clones every repo into ~/code/BACKLOG/repos and checks out DEVELOPMENT
dev-env doctor              # everything should be [ ok ]; read the warnings
```

Commit the BACKLOG skeleton on a work branch and open a merge request (`git -C ~/code/BACKLOG status`).

## 5. VS Code

Always work **connected to WSL**. Never open `\\wsl.localhost\...` folders in a Windows-side VS Code window:
extensions and Copilot CLI sessions would run on Windows with another toolchain and duplicated indexes.

```bash
cd ~/code/BACKLOG/repos/<repo>
code .                      # the first time VS Code installs its server inside WSL
dev-env vscode-ext          # installs the WSL-side extensions
```

Check inside VS Code (bottom-left corner must say **WSL: Ubuntu-24.04**):
- Command Palette -> **MCP: List Servers**: context7 (and codegraph/Ikaro when configured) are listed.
  If not, run **MCP: Open Remote User Configuration** and compare with `~/.vscode-server/data/User/mcp.json`.
- Chat view -> Configure Chat -> Instructions: `general` is listed (comes from `~/.copilot/instructions`).
- Chat view -> **New Copilot CLI session** -> isolation **Worktree**: the session must see Java 8 and Maven
  (ask it to run `java -version` and `mvn -v`).

## 6. Updating

- From Ubuntu: `dev-env update` (pulls the kit and re-runs provisioning; needs `DEV_SUDO=nopasswd`).
- From Windows: update the kit folder (`git pull`) and run `INSTALL-WINDOWS.cmd` again.
- Applying new versions: edit `versions.env`, publish, then update.

## 7. Reset

To start over, destroy the distro (**all data inside it is lost**; push your work first):

```powershell
wsl --unregister Ubuntu-24.04
```

Then run `INSTALL-WINDOWS.cmd` again.

## 8. Security notes

- `DEV_SUDO=nopasswd` (default) gives the `developer` user passwordless sudo inside WSL for simplicity. Set
  `DEV_SUDO=none` in `config/kit.env` to disable it (privileged tasks then use `wsl -u root` from Windows).
- Git hooks block commits, merges and pushes on `DEVELOPMENT` and `MASTER`, but `--no-verify` bypasses them. They are
  a safety net; the shared instructions also forbid it. Merge requests remain the control point.
- Copilot CLI sessions with worktree isolation run with approvals bypassed (VS Code behaviour). Jira and Artifactory
  are read-only and SSH to the client platform is not configured on purpose.
- `gh` and `glab` store an OAuth token in WSL after the browser login. Anything running as `developer` can use it.
- MCP files that may contain credentials are written with mode 600.
