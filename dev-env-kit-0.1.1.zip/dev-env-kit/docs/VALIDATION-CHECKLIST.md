# Validation checklist (first run on the company Windows laptop)

The kit was developed and tested in a Linux sandbox (Ubuntu 24.04, the same distribution WSL installs). The Windows
side could **not** be executed there. Follow this list in order; the riskiest steps come first. For every step write
down the result and, when it fails, the exact message, then fix it (see TROUBLESHOOTING.md) or report it.

## What was verified before delivery

| Verified | How |
|---|---|
| All shell scripts parse; shellcheck clean at warning level | `bash -n`, `shellcheck` |
| Both PowerShell scripts parse with the real PowerShell parser (7.0.3, Linux) and run end to end against a fake `wsl.exe` and mocked Windows cmdlets (checks, `.wslconfig`, VS Code setting, distro install, kit copy, user creation) | `tests/parse-ps.ps1` plus a harness |
| 76 automated tests: git hooks, `bk-*` commands, workspace/umbrella generation, MCP merge, OpenSpec onboarding | `tests/run-tests.sh` |
| The CRLF-to-LF and executable-bit normalisation used by the Windows installer | Same snippet executed on a CRLF copy of the kit |
| Provisioning modules 05, 10, 20 (JDK 8), 30 (skip path), 40 (gh, npm packages, markitdown), 45, 50 and the doctor | Real run, as root then as `developer`, on Ubuntu 24.04 |
| `openjdk-8-jdk-headless` exists in Ubuntu 24.04 | apt |
| Copilot CLI 1.0.105 lists the 6 OpenSpec skills as *Personal skills*, loads `~/.copilot/copilot-instructions.md` (through the symlink) and reads `~/.copilot/mcp-config.json` | `copilot skill list`, `copilot instruction list`, `copilot mcp list` |
| `openspec init --tools none` creates only `openspec/` | Real run |
| `dev-env identity`, `setup-repos`, `refresh-skills`, `freeze`, `link-instructions` | Real run with local bare repositories |

## What could NOT be verified (check these)

| # | Not verified | Where it matters |
|---|---|---|
| 1 | PowerShell scripts never ran on real Windows PowerShell 5.1 with the real `wsl.exe` (0.1.0 failed to parse; fixed in 0.1.1) | Steps 1-3 below |
| 2 | `wsl --install -d Ubuntu-24.04 --no-launch` followed by `wsl -u root --exec ...` works without the first-run user wizard | Step 3 |
| 3 | Downloads blocked in the sandbox: Maven 3.3.3 (archive.apache.org / Maven Central), Node.js (nodejs.org), glab (gitlab.com), gh apt repository | Step 4 |
| 4 | `wslview` opens the Windows browser for `gh` / Copilot login | Step 6 |
| 5 | Login to the client GitLab with `glab` (browser flow vs personal access token) | Step 6 |
| 6 | VS Code reads `~/.vscode-server/data/User/mcp.json` and `~/.copilot/instructions` in a WSL window | Step 8 |
| 7 | VS Code Copilot CLI sessions run inside WSL, with worktree isolation, and the git hooks apply in the worktree | Step 9 |
| 8 | Organization MCP policy allows context7, codegraph, Ikaro | Step 8 |
| 9 | TeX Live minimal set is enough for `pandoc --pdf-engine=xelatex` | Step 10 |
| 10 | `COPILOT_CUSTOM_INSTRUCTIONS_DIRS` is not used by the kit: with the test version it did not pick up a root-level `*.instructions.md` file | informational |

## Steps

| Step | Action | Expected result | Result / notes |
|---|---|---|---|
| 1 | Open PowerShell, `cd C:\dev-env-kit`, run `.\INSTALL-WINDOWS.cmd` (as a normal user; elevate only if asked) | Step 1 prints green checks, creates `.wslconfig`, installs VS Code extensions; no PowerShell syntax errors | |
| 2 | If WSL had to be installed: restart and run again | Step 1 passes without installing | |
| 3 | Step 2 runs: distro install, "root access works", "Kit copied", "User ready" | `wsl -l -v` shows `Ubuntu-24.04` (Running/Stopped, version 2); `wsl -d Ubuntu-24.04 whoami` prints `developer` | |
| 4 | Provisioning output | Modules 10, 20, 30, 40, 50 end with `finished`; for any download failure use `vendor/` and re-run | |
| 5 | In Ubuntu: `dev-env doctor` | No `[FAIL]` (warnings about login, repos, internal tools are expected before first use) | |
| 6 | `dev-env identity`, `dev-env login`, `copilot` then `/login` | Browser opens on Windows; `gh auth status` and `glab auth status` are OK; Copilot answers | |
| 7 | `dev-env setup-repos`, edit `repos.tsv`, `bk-clone-all`, `bk-sync` | BACKLOG and KNOWLEDGE-BASE cloned; client repos on `DEVELOPMENT`; no branch warnings | |
| 8 | `cd ~/code/BACKLOG/repos/<repo> && code .`, then `dev-env vscode-ext` | VS Code shows **WSL: Ubuntu-24.04**; *MCP: List Servers* shows context7 (and codegraph/Ikaro); Chat -> Instructions lists `general`; `mvn -v` and `java -version` in the VS Code terminal show 3.3.3 and 1.8 | |
| 9 | Chat -> New Copilot CLI session -> *Worktree*; ask it to run `java -version`, `mvn -v`, `pwd`, then `git commit` on the worktree branch and on a copy of `DEVELOPMENT` | Runs inside WSL; worktree outside `repos/`; commit on a feature branch works; on `DEVELOPMENT` it is blocked | |
| 10 | `markitdown some.pdf`; `echo '# Test' > /tmp/t.md && pandoc /tmp/t.md -o /tmp/t.pdf --pdf-engine=xelatex` | Markdown text; a PDF is produced | |
| 11 | `mvn -q test` in a small repo; `dev-env doctor --deep` | Dependencies resolve through Artifactory | |
| 12 | `bk-onboard-repo <repo>` on a throwaway repo (no `--mr`), inspect `git show --stat` | Only `openspec/` changed; `copilot skill list` shows the OpenSpec skills | |
| 13 | In a repo with `openspec/`: `/openspec-propose "test change"` in Copilot | A change folder with proposal, specs, design and tasks is created | |
| 14 | Umbrella dry run: `bk-umbrella-new PROJ-1 demo`, `bk-workspace PROJ-1 <repoA> <repoB>`, `code` the workspace | Template files created; workspace opens with 4 roots; search finds code in both repos | |
| 15 | Second laptop / second person with less experience follows INSTALL.md alone | Completes without help; note the questions they asked | |

## When something fails

Collect: the failing step, the full message, `wsl --version`, `wsl -l -v`, the last log in `/var/log/dev-env/`, and
`dev-env doctor` output. Fix in the kit (`wsl/` or `windows/`), bump `VERSION`, and run `tests/run-tests.sh` before
re-publishing.
