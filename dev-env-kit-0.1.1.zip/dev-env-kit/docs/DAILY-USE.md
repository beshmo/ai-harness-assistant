# Daily use

All commands run inside Ubuntu (WSL). Hard rules: **never commit or push to `DEVELOPMENT` or `MASTER`**, never use
`--no-verify`, and always go through merge requests. The git hooks enforce the first rule locally.

## Start of the day

```bash
bk-sync                       # fetch every client repo; fast-forwards clean DEVELOPMENT checkouts
```

## A. Small corrective fix (no OpenSpec)

Use it only when behaviour described in the specs does not change.

```bash
bk-new-branch -t fix -r <repo> PROJ-123 null-pointer-in-search     # branch fix/PROJ-123-null-pointer-in-search
code ~/code/BACKLOG/repos/<repo>                                   # open ONLY that repo, connected to WSL
```

Work with Copilot, build and test with Maven 3.3.3 (`mvn -q test`), then:

```bash
git commit -am "PROJ-123: fix null pointer in search"
git push -u origin fix/PROJ-123-null-pointer-in-search
glab mr create --target-branch DEVELOPMENT --fill --yes            # merge request into DEVELOPMENT
```

Deploy and test manually on DEV.

## B. Evolutive change with OpenSpec (one repository)

1. First time in this repo only: `bk-onboard-repo <repo> --mr` (adds the `openspec/` folder and opens a merge request;
   wait for it to be merged, then `bk-sync <repo>`).
2. `bk-new-branch -r <repo> PROJ-200 new-export-format`, then open the repo in VS Code.
3. In Copilot (CLI or Chat) run the OpenSpec skills in this order, with a **human review between every step**:

| Step | Skill | Review |
|---|---|---|
| Think / clarify | `/openspec-explore` | optional |
| Propose | `/openspec-propose "describe the change"` | **Review proposal, design, specs and tasks before continuing** |
| Implement | `/openspec-apply-change` | Review the diff (ask an agent to review it too) |
| Close | `/openspec-archive-change` | specs are updated and the change is archived |

4. Commit with the Jira key prefix, push, merge request, manual deployment and test.

The skills are installed for your user (`~/.copilot/skills`); the repo only contains the `openspec/` folder.

## C. Change that touches several repositories (umbrella)

```bash
bk-umbrella-new PROJ-300 shared-lib-upgrade     # creates ~/code/BACKLOG/changes/PROJ-300-shared-lib-upgrade/
```

1. **Analyse in BACKLOG**: fill `analysis.md` (impacted repos, contracts, risks) with the help of Ikaro and codegraph.
   Review it (pull request on BACKLOG) before touching any repo. Use a multi-root workspace for cross-repo reading:
   `bk-workspace PROJ-300 repo-a repo-b repo-c` then `code ~/code/BACKLOG/workspaces/PROJ-300.code-workspace`.
2. **Plan**: fill `plan.md` (order, dependencies, artifact versions: a library change reaches consumers only through
   Artifactory after Jenkins publishes it) and `acceptance.md` (deployment order, manual test, rollback).
3. **One brief per repo**: copy `repos/_brief.md` to `repos/<repo>.md`, self-contained.
4. **Implement repo by repo**, flow B, using the **same KEY and slug**: OpenSpec change `PROJ-300-shared-lib-upgrade`,
   branch `feature/PROJ-300-shared-lib-upgrade`, commit prefix `PROJ-300:`. Give the agent the brief and keep a copy as
   `openspec/changes/PROJ-300-shared-lib-upgrade/umbrella-brief.md`. In the Copilot CLI you can grant access to the
   analysis with `/add-dir ~/code/BACKLOG/changes/PROJ-300-shared-lib-upgrade`.
5. Update the status column of `plan.md` at every milestone.

## D. Parallel work

- **VS Code (recommended):** open the repo, Chat view -> *New Copilot CLI session* -> isolation *Worktree*. Each session
  gets its own worktree and branch; sessions keep running if you close the window. Keep an eye on the consumption of
  premium requests and start with 1-2 parallel sessions.
- **Terminal:** `bk-new-branch -w -r <repo> PROJ-400 other-task` creates `~/code/worktrees/<repo>/PROJ-400-other-task`;
  open it with `code <path>`. Remove it when done: `git -C ~/code/BACKLOG/repos/<repo> worktree remove <path>`.

Worktree sessions run with approvals bypassed: read the diff before you push.

## E. Documentation and knowledge

```bash
markitdown file.pdf > file.md                    # PDF/Word/Excel/PowerPoint to Markdown
pandoc file.md -o file.pdf --pdf-engine=xelatex  # Markdown to PDF
```

The KNOWLEDGE-BASE repository (documents + Ikaro index) is maintained by the knowledge-base owner. Ask the agent to
consult Ikaro before relying on any OpenText API.

## Cheat sheet

| I want to... | Command |
|---|---|
| see the state of all repos | `bk-sync` |
| start a work branch | `bk-new-branch [-t fix] [-w] [-r repo] KEY slug` |
| add OpenSpec to a repo | `bk-onboard-repo <repo> --mr` |
| start a cross-repo change | `bk-umbrella-new KEY slug` |
| read several repos at once | `bk-workspace KEY repo...` |
| check my installation | `dev-env doctor` |
| update the environment | `dev-env update` |
