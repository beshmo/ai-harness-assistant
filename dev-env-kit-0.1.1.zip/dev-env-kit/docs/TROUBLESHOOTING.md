# Troubleshooting

Start with `dev-env doctor` (inside Ubuntu): it points to most problems. Provisioning logs are in
`/var/log/dev-env/` (inside the distro).

## Windows installer

| Symptom | Cause / fix |
|---|---|
| "running scripts is disabled" | Use `INSTALL-WINDOWS.cmd` (it bypasses the policy for this run). If the zip was blocked: right-click the zip -> Properties -> Unblock, before unzipping. |
| "WSL is not installed" | Run the installer from an elevated terminal **with your own account**, or ask IT to run `wsl --install --no-distribution`. Restart, run again. |
| Exit code 3 / "restart required" | Restart Windows and run `INSTALL-WINDOWS.cmd` again. |
| "Virtualization is disabled" | Enable Intel VT-x / AMD-V (SVM) in the BIOS/UEFI. |
| Distro cannot be installed (Store/network blocked) | Get an Ubuntu 24.04 `.wsl` or rootfs `.tar.gz` and run `02-wsl-ubuntu.ps1 -FromFile <file>`. |
| Wrong distro name | `wsl -l -v` shows the real name; pass it with `-DistroName`. |
| WSL runs out of memory | Edit `%UserProfile%\.wslconfig` (`memory=`), then `wsl --shutdown`. |

## Inside Ubuntu

| Symptom | Cause / fix |
|---|---|
| `$'\r': command not found` | A script has Windows line endings. The installer converts them; if you edited a file in Windows run `sed -i 's/\r$//' <file>`. |
| `curl: (60)` / `PKIX path building failed` / `UNABLE_TO_GET_ISSUER_CERT_LOCALLY` | The company proxy re-signs HTTPS. Put the corporate CA certificates (PEM) in `config/certs/`, run `sudo bash /opt/dev-env/wsl/provision.sh --only 05-certs`, open a new terminal. |
| Downloads fail with 403/connection errors | Place the file in `vendor/` (see `vendor/README.md`) and re-run the installer. If a proxy is required, add `export https_proxy=http://host:port` and `export http_proxy=...` lines to `config/kit.env` (used during installation) and to `/etc/environment` without `export` (used afterwards); npm may also need `npm config set proxy` / `https-proxy`. |
| `mvn -v` is not 3.3.3 or Java is not 1.8 | Re-run `sudo bash /opt/dev-env/wsl/provision.sh --only 20-java`. |
| Maven cannot resolve dependencies (401/403/404) | Check `~/.m2/settings.xml` (copy of `config/maven/settings.xml`), the mirror URL, VPN/network access to Artifactory. `dev-env doctor --deep` reproduces the check. |
| `glab` not installed | The `.deb` could not be downloaded. Save `glab_<version>_linux_amd64.deb` in `vendor/` (or set `GLAB_VERSION`) and run `sudo bash /opt/dev-env/wsl/provision.sh --only 40-cli`. |
| `glab auth login` asks for a token | Some self-managed GitLab servers do not offer the browser flow. Use a personal access token with `api` and `write_repository` scopes, or ask the GitLab admin about OAuth for glab. |
| `gh auth login` does not open the browser | Copy the one-time code and the URL it prints into the Windows browser by hand. `echo $BROWSER` should print `wslview` (open a new terminal after provisioning). |
| `code: command not found` | Open the folder once from Windows VS Code (Remote - WSL) or run it from a Windows terminal; VS Code installs its server in WSL on first connection. |
| VS Code is slow / indexes twice | You opened a `\\wsl.localhost\...` path from Windows. Close it and open the folder with `code .` from Ubuntu. |
| Repo folders under `/mnt/c` | Not supported (slow, permissions). Keep everything under `~/code`. |

## Git hooks

| Message | Meaning |
|---|---|
| `BLOCKED: direct commits on 'DEVELOPMENT'...` | Working directly on a protected branch. Create a branch: `bk-new-branch KEY slug`, then commit. |
| `BLOCKED: pushing to protected branch...` | Push your work branch and open a merge request instead. |
| Need a different pattern | Edit `PROTECTED_BRANCHES_REGEX` in `config/kit.env` and run `dev-env update`. For one shell: `export PROTECTED_BRANCHES_REGEX=...`. |

## Copilot, MCP and OpenSpec

| Symptom | Cause / fix |
|---|---|
| "MCP servers were blocked by policy" | The GitHub organization/enterprise has not enabled "MCP servers in Copilot" (or restricts them to a registry). Ask the GitHub admin. |
| MCP server missing in the CLI | `copilot mcp list` shows what the CLI reads from `~/.copilot/mcp-config.json`. Re-create it with `sudo bash /opt/dev-env/wsl/provision.sh --only 50-agent`. |
| MCP server missing in VS Code | **MCP: List Servers**. If empty, use **MCP: Open Remote User Configuration** and copy the entries from `~/.vscode-server/data/User/mcp.json`. |
| OpenSpec skills not found | `copilot skill list` should show `openspec-*` as *Personal skills*. Fix with `dev-env refresh-skills`. |
| Shared instructions not loaded | `copilot instruction list` should show *Home copilot-instructions.md*. Fix with `dev-env link-instructions`. After editing the shared file, start a new session. |
| Slash commands `/opsx:*` do not exist in the CLI | By design: OpenSpec skills are used instead (`/openspec-propose`, `/openspec-apply-change`...). |
| `openspec: command not found` | Node.js is missing or older than required: `dev-env doctor`, then `sudo bash /opt/dev-env/wsl/provision.sh --only 30-runtimes,40-cli`. |

## Disk space

Maven repositories, the WSL virtual disk and `target/` folders grow. Remove unused worktrees and run `mvn clean` in
repos you no longer touch. To reclaim space from the virtual disk, shut WSL down (`wsl --shutdown`) and compact the
disk with `diskpart` or, if your WSL version supports it, enable sparse disks with `wsl --manage Ubuntu-24.04 --set-sparse true`.
