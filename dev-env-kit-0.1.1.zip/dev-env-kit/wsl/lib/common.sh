#!/usr/bin/env bash
# Shared helpers for the dev-env kit. Source this file; do not execute it.

DEVENV_ROOT="${DEVENV_ROOT:-/opt/dev-env}"
if [ ! -f "$DEVENV_ROOT/versions.env" ]; then
  # Running from a checkout (development, tests).
  DEVENV_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
fi
export DEVENV_ROOT

_c() { if [ -t 1 ]; then printf '\033[%sm' "$1"; fi; }
log()  { printf '%s[dev-env]%s %s\n' "$(_c '1;34')" "$(_c 0)" "$*"; }
ok()   { printf '%s[ ok ]%s %s\n' "$(_c '1;32')" "$(_c 0)" "$*"; }
warn() { printf '%s[warn]%s %s\n' "$(_c '1;33')" "$(_c 0)" "$*" >&2; }
err()  { printf '%s[fail]%s %s\n' "$(_c '1;31')" "$(_c 0)" "$*" >&2; }
die()  { err "$*"; exit 1; }

# Load versions.env, config/kit.env, config/internal-tools.env and optional per-machine overrides.
# Variables are NOT exported on purpose: some tools read env vars with similar names
# (for example Copilot CLI reads COPILOT_CLI_VERSION), and every script loads the config itself.
load_config() {
  # shellcheck disable=SC1091
  . "$DEVENV_ROOT/versions.env"
  # shellcheck disable=SC1091
  . "$DEVENV_ROOT/config/kit.env"
  if [ -f "$DEVENV_ROOT/config/internal-tools.env" ]; then
    # shellcheck disable=SC1091
    . "$DEVENV_ROOT/config/internal-tools.env"
  fi
  if [ -f /etc/dev-env/local.env ]; then
    # shellcheck disable=SC1091
    . /etc/dev-env/local.env
  fi
  return 0
}

have() { command -v "$1" >/dev/null 2>&1; }

need_root() {
  [ "$(id -u)" -eq 0 ] || die "This step must run as root (use sudo, or 'wsl -u root' from Windows)."
}

# Run a shell command line as DEV_USER (directly if we already are that user).
as_dev() {
  if [ "$(id -un)" = "$DEV_USER" ]; then
    bash -c "$1"
  else
    sudo -u "$DEV_USER" -H bash -c "$1"
  fi
}

# apt helpers -------------------------------------------------------------------------
apt_update_once() {
  local stamp=/var/lib/dev-env/apt-updated
  mkdir -p /var/lib/dev-env
  if [ -f "$stamp" ] && [ -z "$(find "$stamp" -mmin +720 2>/dev/null)" ]; then
    return 0
  fi
  DEBIAN_FRONTEND=noninteractive apt-get update -y
  touch "$stamp"
}

apt_install() {
  DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends "$@"
}

# Download helper: uses vendor/<file name> (offline cache) first, otherwise downloads.
# Usage: fetch URL DEST
fetch() {
  local url="$1" dest="$2" name rc=0
  name="$(basename "$dest")"
  if [ -f "$DEVENV_ROOT/vendor/$name" ]; then
    log "Using vendored file vendor/$name"
    cp -f "$DEVENV_ROOT/vendor/$name" "$dest"
    return 0
  fi
  curl -fsSL --retry 3 --retry-delay 2 --connect-timeout 20 -o "$dest" "$url" || rc=$?
  if [ "$rc" -ne 0 ]; then
    err "Download failed (curl exit $rc): $url"
    if [ "$rc" -eq 60 ]; then
      warn "TLS certificate problem: a corporate proxy may inspect HTTPS. See docs/TROUBLESHOOTING.md (corporate CA)."
    fi
    warn "Offline alternative: download it manually and save it as vendor/$name inside the kit."
    return "$rc"
  fi
}

# True if $1 >= $2 (dotted versions).
version_ge() {
  [ "$(printf '%s\n%s\n' "$2" "$1" | sort -V | head -n1)" = "$2" ]
}

# Append a line to a file unless it is already there.
ensure_line() {
  local file="$1" line="$2"
  touch "$file"
  grep -qxF -- "$line" "$file" || printf '%s\n' "$line" >>"$file"
}

# Replace a symlink target safely (moves a real file/dir out of the way once).
safe_link() {
  local target="$1" link="$2"
  mkdir -p "$(dirname "$link")"
  if [ -e "$link" ] && [ ! -L "$link" ]; then
    mv "$link" "$link.bak-$(date +%s)"
  fi
  ln -sfn "$target" "$link"
}

dpkg_arch() { dpkg --print-architecture 2>/dev/null || echo amd64; }

java8_home() { echo "/usr/lib/jvm/java-8-openjdk-$(dpkg_arch)"; }
