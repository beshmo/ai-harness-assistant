#!/usr/bin/env bash
# Agent-related helpers (instructions, MCP configuration, OpenSpec skills).
# Source after common.sh. Functions here run as DEV_USER and use $HOME.

# Link the shared instructions so both Copilot CLI and VS Code Chat load them.
#   VS Code Chat : ~/.copilot/instructions  (user-profile instructions folder, *.instructions.md)
#   Copilot CLI  : ~/.copilot/copilot-instructions.md (user-level instructions file)
# The source of truth is BACKLOG/shared/instructions; until BACKLOG exists the kit template is used.
link_instructions() {
  local src_dir="$BACKLOG_DIR/shared/instructions"
  if [ ! -f "$src_dir/general.instructions.md" ]; then
    src_dir="$DEVENV_ROOT/templates/backlog-skeleton/shared/instructions"
  fi
  safe_link "$src_dir" "$HOME/.copilot/instructions"
  safe_link "$src_dir/general.instructions.md" "$HOME/.copilot/copilot-instructions.md"
  log "Shared instructions linked from $src_dir"
}

# Merge kit-managed MCP servers into the Copilot CLI and VS Code user MCP files.
# Entries not managed by the kit are preserved. Files are written with mode 600.
#   Copilot CLI : ~/.copilot/mcp-config.json          (key: mcpServers)
#   VS Code     : ~/.vscode-server/data/User/mcp.json (key: servers)  -- verify in the pilot
build_mcp_configs() {
  have jq || { warn "jq not installed; MCP configuration skipped"; return 1; }
  local cli_json='{}' vsc_json='{}'

  _mcp_add() {
    local name="$1" cmd="$2" args="${3:-}" env="${4:-}"
    [ -n "$cmd" ] || return 0
    [ -n "$args" ] || args='[]'
    [ -n "$env" ] || env='{}'
    if ! jq -e 'type=="array"' <<<"$args" >/dev/null 2>&1; then
      warn "MCP '$name': *_MCP_ARGS_JSON is not a JSON array; server skipped"; return 0
    fi
    if ! jq -e 'type=="object"' <<<"$env" >/dev/null 2>&1; then
      warn "MCP '$name': *_MCP_ENV_JSON is not a JSON object; server skipped"; return 0
    fi
    cli_json="$(jq --arg n "$name" --arg c "$cmd" --argjson a "$args" --argjson e "$env" \
      '. + {($n): {type:"local", command:$c, args:$a, env:$e, tools:["*"]}}' <<<"$cli_json")"
    vsc_json="$(jq --arg n "$name" --arg c "$cmd" --argjson a "$args" --argjson e "$env" \
      '. + {($n): {type:"stdio", command:$c, args:$a, env:$e}}' <<<"$vsc_json")"
  }

  _mcp_merge_write() {
    local file="$1" key="$2" json="$3" existing='{}'
    mkdir -p "$(dirname "$file")"
    if [ -s "$file" ]; then
      if jq -e . "$file" >/dev/null 2>&1; then
        existing="$(cat "$file")"
      else
        cp "$file" "$file.bak-$(date +%s)"
        warn "$file was not valid JSON; backup kept"
      fi
    fi
    jq -n --argjson ex "$existing" --argjson new "$json" --arg key "$key" \
      '$ex | .[$key] = ((.[$key] // {}) + $new)' >"$file.tmp" && mv "$file.tmp" "$file"
    chmod 600 "$file"
    log "MCP configuration updated: $file"
  }

  _mcp_add context7 context7-mcp '[]' '{}'
  _mcp_add codegraph "${CODEGRAPH_MCP_COMMAND:-}" "${CODEGRAPH_MCP_ARGS_JSON:-}" "${CODEGRAPH_MCP_ENV_JSON:-}"
  _mcp_add ikaro "${IKARO_MCP_COMMAND:-}" "${IKARO_MCP_ARGS_JSON:-}" "${IKARO_MCP_ENV_JSON:-}"
  _mcp_add jira "${JIRA_MCP_COMMAND:-}" "${JIRA_MCP_ARGS_JSON:-}" "${JIRA_MCP_ENV_JSON:-}"

  _mcp_merge_write "$HOME/.copilot/mcp-config.json" mcpServers "$cli_json"
  _mcp_merge_write "$HOME/.vscode-server/data/User/mcp.json" servers "$vsc_json"
}

# Install the OpenSpec skills at user level (~/.copilot/skills) so client repositories only need
# the openspec/ folder. The skills are generic: they are generated once in a scratch repository.
export_openspec_skills() {
  have openspec || { warn "openspec not installed; skills export skipped"; return 0; }
  local tmp n=0 d
  tmp="$(mktemp -d)"
  if ! (
    cd "$tmp" && git init -q &&
    OPENSPEC_TELEMETRY=0 openspec config set delivery skills >/dev/null 2>&1 &&
    OPENSPEC_TELEMETRY=0 openspec init --tools github-copilot </dev/null >/dev/null 2>&1
  ); then
    warn "Could not generate the OpenSpec skills (openspec init failed)"
    rm -rf "$tmp"
    return 1
  fi
  for d in "$tmp"/.github/skills/openspec-*; do [ -d "$d" ] && n=$((n + 1)); done
  if [ "$n" -eq 0 ]; then
    warn "OpenSpec generated no skills; ~/.copilot/skills left untouched"
    rm -rf "$tmp"
    return 1
  fi
  mkdir -p "$HOME/.copilot/skills"
  rm -rf "$HOME"/.copilot/skills/openspec-*
  for d in "$tmp"/.github/skills/openspec-*; do cp -a "$d" "$HOME/.copilot/skills/"; done
  openspec --version >"$HOME/.copilot/skills/.openspec-version" 2>/dev/null || true
  rm -rf "$tmp"
  log "OpenSpec skills installed in ~/.copilot/skills ($n skills)"
}
