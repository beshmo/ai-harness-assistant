#!/usr/bin/env bash
# Node.js (official tarball, checksum verified) and global npm prefix. Python/pipx come from module 10.
set -euo pipefail
. "$DEVENV_ROOT/wsl/lib/common.sh"
load_config
need_root

current_major=""
if have node; then current_major="$(node -v | sed 's/^v//; s/\..*//')"; fi

if [ "$current_major" = "$NODE_MAJOR" ]; then
  ok "Node.js $(node -v) already installed"
else
  case "$(uname -m)" in
    x86_64) arch=x64 ;;
    aarch64) arch=arm64 ;;
    *) die "Unsupported architecture $(uname -m)" ;;
  esac
  tmp="$(mktemp -d)"
  base="https://nodejs.org/dist/latest-v${NODE_MAJOR}.x"
  fetch "$base/SHASUMS256.txt" "$tmp/SHASUMS256.txt" || die "Could not fetch Node.js checksums (see vendor/README.md for the offline option)"
  line="$(grep "node-v.*-linux-$arch.tar.xz" "$tmp/SHASUMS256.txt" | head -n1)"
  [ -n "$line" ] || die "No Linux $arch tarball listed for Node.js $NODE_MAJOR"
  sha="$(awk '{print $1}' <<<"$line")"
  file="$(awk '{print $2}' <<<"$line")"
  fetch "$base/$file" "$tmp/$file" || die "Could not download $file"
  echo "$sha  $tmp/$file" | sha256sum -c - >/dev/null || die "Node.js archive checksum mismatch"
  ok "Node.js archive checksum verified"
  tar -xJf "$tmp/$file" -C /opt
  nodedir="/opt/${file%.tar.xz}"
  ln -sfn "$nodedir" /opt/node
  for bin in node npm npx corepack; do
    [ -e "$nodedir/bin/$bin" ] && ln -sfn "/opt/node/bin/$bin" "/usr/local/bin/$bin"
  done
  rm -rf "$tmp"
fi

hash -r
node -v
version_ge "$(node -v | sed 's/^v//')" "$NODE_MIN_VERSION" || die "Node.js $(node -v) is older than the required $NODE_MIN_VERSION"

# Global npm packages go to /usr/local (on PATH for every shell, updated with sudo).
npm config set prefix /usr/local --location=global
ok "npm global prefix: $(npm config get prefix)"

python3 --version
pipx --version
