#!/usr/bin/env bash
# Command line tools: gh, glab, Copilot CLI, OpenSpec, context7 MCP, markitdown.
set -euo pipefail
. "$DEVENV_ROOT/wsl/lib/common.sh"
load_config
need_root

# --- GitHub CLI (official apt repository, Ubuntu package as fallback) ------------------------
if have gh; then
  ok "gh already installed: $(gh --version | head -n1)"
else
  keyring=/etc/apt/keyrings/githubcli-archive-keyring.gpg
  install -d -m 755 /etc/apt/keyrings
  if fetch https://cli.github.com/packages/githubcli-archive-keyring.gpg "$keyring"; then
    chmod go+r "$keyring"
    echo "deb [arch=$(dpkg_arch) signed-by=$keyring] https://cli.github.com/packages stable main" >/etc/apt/sources.list.d/github-cli.list
    apt-get update -y || true
  else
    warn "GitHub CLI apt repository unreachable; falling back to the Ubuntu package (older)"
    rm -f /etc/apt/sources.list.d/github-cli.list
  fi
  apt_install gh
fi

# --- GitLab CLI (.deb from GitLab releases; optional file in vendor/) ------------------------
install_glab() {
  local ver="$GLAB_VERSION" arch tmp deb
  arch="$(dpkg_arch)"
  tmp="$(mktemp -d)"
  if [ "$ver" = "latest" ]; then
    ver="$(curl -fsSL --connect-timeout 20 'https://gitlab.com/api/v4/projects/gitlab-org%2Fcli/releases/permalink/latest' | jq -r '.tag_name' | sed 's/^v//')" || true
    if [ -z "$ver" ] || [ "$ver" = "null" ]; then
      warn "Could not resolve the latest glab version (set GLAB_VERSION in versions.env or put the .deb in vendor/)"
      ls "$DEVENV_ROOT"/vendor/glab_*_linux_"$arch".deb >/dev/null 2>&1 || return 1
      deb="$(ls "$DEVENV_ROOT"/vendor/glab_*_linux_"$arch".deb | head -n1)"
      apt_install "$deb"
      return 0
    fi
  fi
  deb="glab_${ver}_linux_${arch}.deb"
  fetch "https://gitlab.com/gitlab-org/cli/-/releases/v${ver}/downloads/$deb" "$tmp/$deb" || return 1
  apt_install "$tmp/$deb"
  rm -rf "$tmp"
}
if have glab; then
  ok "glab already installed: $(glab --version | head -n1)"
else
  install_glab || warn "glab was NOT installed. Install it later (docs/TROUBLESHOOTING.md) - 'dev-env doctor' will keep reporting it."
fi

# --- npm global packages -------------------------------------------------------------------
npm_global() {
  local pkg="$1" ver="$2"
  log "npm install -g $pkg@$ver"
  npm install -g "$pkg@$ver" --no-fund --no-audit
}
npm_global @github/copilot "$COPILOT_PACKAGE_VERSION"
npm_global @fission-ai/openspec "$OPENSPEC_VERSION"
npm_global @upstash/context7-mcp "$CONTEXT7_MCP_VERSION"

# Opt out of OpenSpec anonymous telemetry for the developer user.
as_dev "OPENSPEC_TELEMETRY=0 openspec config set telemetry.enabled false >/dev/null 2>&1 || true"

# --- markitdown (isolated with pipx, system-wide) -------------------------------------------
export PIPX_HOME=/opt/pipx PIPX_BIN_DIR=/usr/local/bin
spec="markitdown[$MARKITDOWN_EXTRAS]"
if [ "$MARKITDOWN_VERSION" != "latest" ]; then spec="$spec==$MARKITDOWN_VERSION"; fi
if pipx list --short 2>/dev/null | grep -q '^markitdown '; then
  if [ "$MARKITDOWN_VERSION" = "latest" ]; then pipx upgrade markitdown || true; else pipx install --force "$spec"; fi
else
  pipx install "$spec"
fi

ok "CLI tools installed"
for t in gh glab copilot openspec context7-mcp markitdown pandoc; do
  if have "$t"; then ok "$t: found"; else warn "$t: NOT found"; fi
done
