#!/usr/bin/env bash
# Agent environment: directories, profile, helper commands, git hooks, instructions, MCP, skills.
set -euo pipefail
. "$DEVENV_ROOT/wsl/lib/common.sh"
. "$DEVENV_ROOT/wsl/lib/agent.sh"
load_config
need_root

# --- directories ------------------------------------------------------------------------------
for d in "$CODE_DIR" "$DOCS_DIR" "$WORKTREES_DIR"; do
  mkdir -p "$d"
  chown "$DEV_USER:$DEV_USER" "$d"
done

# --- executable bits (files copied from Windows lose them) and command links --------------------
find "$DEVENV_ROOT/wsl" "$DEVENV_ROOT/git-hooks" -type f \( -name '*.sh' -o -path '*/wsl/bin/*' -o -path '*/git-hooks/*' \) -exec chmod +x {} +
for f in "$DEVENV_ROOT"/wsl/bin/*; do
  ln -sfn "$f" "/usr/local/bin/$(basename "$f")"
done
ok "Commands available: $(ls "$DEVENV_ROOT/wsl/bin" | tr '\n' ' ')"

# --- shell environment for every login ------------------------------------------------------------
cat >/etc/profile.d/dev-env.sh <<EOF
# Managed by the dev-env kit. Do not edit (re-run provisioning instead).
export DEVENV_ROOT="$DEVENV_ROOT"
export JAVA_HOME="$(java8_home)"
export OPENSPEC_TELEMETRY=0
export CODE_DIR="$CODE_DIR"
export BACKLOG_DIR="$BACKLOG_DIR"
export KNOWLEDGE_BASE_DIR="$KNOWLEDGE_BASE_DIR"
export WORKTREES_DIR="$WORKTREES_DIR"
export GITLAB_HOST="$GITLAB_HOST"
if command -v wslview >/dev/null 2>&1; then export BROWSER=wslview; fi
EOF
chmod 644 /etc/profile.d/dev-env.sh
# Non-login interactive shells (VS Code terminals) read /etc/bash.bashrc.
ensure_line /etc/bash.bashrc '[ -r /etc/profile.d/dev-env.sh ] && . /etc/profile.d/dev-env.sh'
ensure_line /etc/bash.bashrc '[ -r /etc/profile.d/dev-env-certs.sh ] && . /etc/profile.d/dev-env-certs.sh'

# --- git: system-wide hooks and safe defaults ---------------------------------------------------------
printf '%s\n' "$PROTECTED_BRANCHES_REGEX" >/etc/dev-env/protected-branches
chmod 644 /etc/dev-env/protected-branches
git config --system core.hooksPath "$DEVENV_ROOT/git-hooks"
git config --system pull.ff only
ok "Git hooks active system-wide (protected: $PROTECTED_BRANCHES_REGEX)"

# --- per-user agent configuration (as the developer user) -------------------------------------------------
run_user_step() {
  local fn="$1"
  as_dev "export DEVENV_ROOT='$DEVENV_ROOT'; . '$DEVENV_ROOT/wsl/lib/common.sh'; . '$DEVENV_ROOT/wsl/lib/agent.sh'; load_config; $fn"
}
run_user_step link_instructions
run_user_step build_mcp_configs
run_user_step export_openspec_skills || warn "OpenSpec skills were not exported; run 'dev-env refresh-skills' later"

chown -R "$DEV_USER:$DEV_USER" "$DEV_HOME/.copilot" "$DEV_HOME/.vscode-server" 2>/dev/null || true
ok "Agent environment configured"
