#!/usr/bin/env bash
# Installs the company tools (codegraph, Ikaro) using the commands configured in config/internal-tools.env.
set -euo pipefail
. "$DEVENV_ROOT/wsl/lib/common.sh"
load_config
need_root

install_tool() {
  local name="$1" cmd="$2"
  if [ -z "$cmd" ]; then
    warn "$name: no install command in config/internal-tools.env (skipped)"
    return 0
  fi
  log "Installing $name"
  bash -c "$cmd"
  ok "$name installed"
}

install_tool codegraph "${CODEGRAPH_INSTALL_CMD:-}"
install_tool ikaro "${IKARO_INSTALL_CMD:-}"

if [ -z "${JIRA_MCP_COMMAND:-}" ]; then
  warn "Jira MCP not configured (waiting for the client to confirm Jira Cloud or Data Center)"
fi
