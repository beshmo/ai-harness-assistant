#!/usr/bin/env bash
# OpenJDK 8, Maven 3.3.3 and the common ~/.m2/settings.xml.
set -euo pipefail
. "$DEVENV_ROOT/wsl/lib/common.sh"
load_config
need_root

# --- OpenJDK 8 ----------------------------------------------------------------------------
apt_update_once
apt_install openjdk-8-jdk-headless ca-certificates-java || die "openjdk-8-jdk-headless is not available from apt. Place a JDK 8 package or tarball in vendor/ and adapt this module."
JAVA8="$(java8_home)"
update-alternatives --set java "$JAVA8/jre/bin/java" >/dev/null 2>&1 || true
update-alternatives --set javac "$JAVA8/bin/javac" >/dev/null 2>&1 || true
java -version 2>&1 | head -n1

# --- Maven ----------------------------------------------------------------------------------
MVN_DIR="/opt/apache-maven-$MAVEN_VERSION"
if [ -x "$MVN_DIR/bin/mvn" ]; then
  ok "Maven $MAVEN_VERSION already installed"
else
  tmp="$(mktemp -d)"
  tgz="apache-maven-$MAVEN_VERSION-bin.tar.gz"
  got=""
  for base in \
    "https://archive.apache.org/dist/maven/maven-3/$MAVEN_VERSION/binaries" \
    "https://repo.maven.apache.org/maven2/org/apache/maven/apache-maven/$MAVEN_VERSION"; do
    if fetch "$base/$tgz" "$tmp/$tgz"; then
      got="$base"
      break
    fi
  done
  [ -n "$got" ] || die "Could not download Maven $MAVEN_VERSION. Put $tgz in vendor/ and re-run."

  # Verify the SHA-1 published next to the archive (best effort: warn if unavailable).
  if fetch "$got/$tgz.sha1" "$tmp/$tgz.sha1" 2>/dev/null; then
    expected="$(awk '{print $1}' "$tmp/$tgz.sha1" | head -n1)"
    actual="$(sha1sum "$tmp/$tgz" | awk '{print $1}')"
    [ "$expected" = "$actual" ] || die "Maven archive checksum mismatch (expected $expected, got $actual)"
    ok "Maven archive checksum verified"
  else
    warn "Could not fetch the published checksum; Maven archive not verified"
  fi

  tar -xzf "$tmp/$tgz" -C /opt
  rm -rf "$tmp"
fi
ln -sfn "$MVN_DIR" /opt/maven
ln -sfn /opt/maven/bin/mvn /usr/local/bin/mvn
mvn -v | head -n1

# --- ~/.m2/settings.xml ---------------------------------------------------------------------
M2="$DEV_HOME/.m2"
SRC="$DEVENV_ROOT/config/maven/settings.xml"
[ -f "$SRC" ] || SRC="$DEVENV_ROOT/config/maven/settings.xml.template"
mkdir -p "$M2"
if [ ! -f "$M2/settings.xml" ] || [ "${FORCE_SETTINGS:-0}" = "1" ]; then
  install -m 600 "$SRC" "$M2/settings.xml"
  ok "Installed $M2/settings.xml from $(basename "$SRC")"
elif ! cmp -s "$SRC" "$M2/settings.xml"; then
  warn "$M2/settings.xml differs from the kit version; kept as is (FORCE_SETTINGS=1 overwrites it)"
fi
chown -R "$DEV_USER:$DEV_USER" "$M2"
if grep -q "CHANGE_ME" "$M2/settings.xml"; then
  warn "settings.xml still contains CHANGE_ME placeholders: copy the project's real settings.xml to config/maven/settings.xml"
fi
