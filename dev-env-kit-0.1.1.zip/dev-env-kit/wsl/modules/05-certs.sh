#!/usr/bin/env bash
# Installs corporate CA certificates from config/certs (optional).
set -euo pipefail
. "$DEVENV_ROOT/wsl/lib/common.sh"
load_config
need_root

shopt -s nullglob
certs=("$DEVENV_ROOT"/config/certs/*.crt "$DEVENV_ROOT"/config/certs/*.pem)
if [ "${#certs[@]}" -eq 0 ]; then
  log "No corporate CA certificates in config/certs (nothing to do)"
  exit 0
fi

apt_update_once
apt_install ca-certificates openssl

for cert in "${certs[@]}"; do
  base="$(basename "$cert")"
  base="${base%.*}"
  if ! openssl x509 -in "$cert" -noout >/dev/null 2>&1; then
    warn "$cert is not a PEM certificate; skipped"
    continue
  fi
  install -m 644 "$cert" "/usr/local/share/ca-certificates/devenv-$base.crt"
  ok "Installed CA certificate $base"
done
update-ca-certificates

cat >/etc/profile.d/dev-env-certs.sh <<'EOF'
# Managed by the dev-env kit: make Node.js and Python use the Ubuntu trust store.
export NODE_EXTRA_CA_CERTS=/etc/ssl/certs/ca-certificates.crt
export SSL_CERT_FILE=/etc/ssl/certs/ca-certificates.crt
export REQUESTS_CA_BUNDLE=/etc/ssl/certs/ca-certificates.crt
export PIP_CERT=/etc/ssl/certs/ca-certificates.crt
EOF
chmod 644 /etc/profile.d/dev-env-certs.sh
ok "Trust store updated (Java picks it up through ca-certificates-java when installed)"
