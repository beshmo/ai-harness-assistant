#!/usr/bin/env bash
# Base packages: git, pandoc, TeX, Python, wslu (opens the Windows browser) and common tools.
set -euo pipefail
. "$DEVENV_ROOT/wsl/lib/common.sh"
load_config
need_root

apt_update_once
apt_install ca-certificates curl wget gnupg git unzip zip xz-utils jq tmux rsync \
  build-essential pandoc python3 python3-venv python3-pip pipx wslu locales less \
  nano tree openssh-client lsb-release

case "$TEX_PROFILE" in
  minimal)
    log "Installing a minimal TeX Live set for pandoc PDF output"
    apt_install texlive-xetex texlive-latex-recommended texlive-fonts-recommended lmodern
    ;;
  full)
    log "Installing full TeX Live (several GB)"
    apt_install texlive-full
    ;;
  none) log "TEX_PROFILE=none: TeX not installed" ;;
  *) die "TEX_PROFILE must be minimal, full or none (got '$TEX_PROFILE')" ;;
esac

ok "Base packages installed"
