#!/usr/bin/env bash
# dev-env doctor: read-only health check of the installation. Exit code 1 if any check FAILs.
# Usage: doctor.sh [--deep]     (--deep also resolves a Maven dependency through Artifactory)
# shellcheck disable=SC2088  # "~" inside messages is literal text on purpose
set -uo pipefail
. "${DEVENV_ROOT:-/opt/dev-env}/wsl/lib/common.sh"
load_config

DEEP=0
[ "${1:-}" = "--deep" ] && DEEP=1

PASS=0; WARN=0; FAIL=0
p() { PASS=$((PASS + 1)); printf '  %s[ ok ]%s %s\n' "$(_c '1;32')" "$(_c 0)" "$*"; }
w() { WARN=$((WARN + 1)); printf '  %s[warn]%s %s\n' "$(_c '1;33')" "$(_c 0)" "$*"; }
f() { FAIL=$((FAIL + 1)); printf '  %s[FAIL]%s %s\n' "$(_c '1;31')" "$(_c 0)" "$*"; }
section() { printf '\n%s%s%s\n' "$(_c '1')" "$*" "$(_c 0)"; }
first_line() { "$@" 2>&1 | head -n1; }

probe() { # name url
  local code rc=0
  code="$(curl -s -o /dev/null -m 10 -w '%{http_code}' -I "$2")" || rc=$?
  if [ "$rc" -eq 60 ] || [ "$rc" -eq 35 ]; then
    f "$1: TLS certificate problem (curl $rc). Corporate proxy? See docs/TROUBLESHOOTING.md (corporate CA)"
  elif [ "$rc" -ne 0 ]; then
    f "$1 unreachable (curl exit $rc). Check VPN/proxy settings"
  else
    case "$code" in
      2*|3*|401|403) p "$1 reachable (HTTP $code)" ;;
      *) w "$1 answered HTTP $code" ;;
    esac
  fi
}

printf 'dev-env doctor (kit %s)\n' "$(cat "$DEVENV_ROOT/VERSION" 2>/dev/null || echo '?')"

section "Platform"
if uname -r | grep -qi 'microsoft'; then p "Running inside WSL ($(uname -r))"; else w "Not running inside WSL ($(uname -r))"; fi
if uname -r | grep -qi 'WSL2'; then p "WSL 2 kernel"; else w "Kernel does not look like WSL 2"; fi
if [ "$(id -un)" = "$DEV_USER" ]; then p "Running as '$DEV_USER'"; else w "Running as '$(id -un)', expected '$DEV_USER'"; fi
free_gb=$(df -BG --output=avail / | tail -n1 | tr -dc '0-9')
if [ "${free_gb:-0}" -ge 10 ]; then p "Free disk space: ${free_gb} GB"; else w "Low free disk space: ${free_gb} GB"; fi
mem_gb=$(awk '/MemTotal/ {printf "%d", $2/1024/1024}' /proc/meminfo)
if [ "${mem_gb:-0}" -ge 6 ]; then p "Memory available to WSL: ${mem_gb} GB"; else w "Only ${mem_gb} GB for WSL; raise 'memory' in %UserProfile%\\.wslconfig"; fi

section "Toolchain"
if have java && java -version 2>&1 | head -n1 | grep -q '1\.8'; then p "Java: $(java -version 2>&1 | head -n1)"; else f "Java 8 not active: $(first_line java -version)"; fi
if have mvn && mvn -v 2>/dev/null | head -n1 | grep -q "Apache Maven $MAVEN_VERSION"; then p "Maven: $(mvn -v | head -n1)"; else f "Maven $MAVEN_VERSION not found"; fi
if have node && version_ge "$(node -v | sed 's/^v//')" "$NODE_MIN_VERSION"; then p "Node.js $(node -v)"; else f "Node.js >= $NODE_MIN_VERSION not found"; fi
for t in git jq python3 pipx pandoc; do
  if have "$t"; then p "$t: $(first_line "$t" --version)"; else f "$t not found"; fi
done
if have tmux; then p "tmux: $(first_line tmux -V)"; else f "tmux not found"; fi
if [ "$TEX_PROFILE" != "none" ]; then
  if have xelatex; then p "xelatex present (pandoc PDF output)"; else w "xelatex not found (TEX_PROFILE=$TEX_PROFILE)"; fi
fi

section "Agent tools"
for t in gh glab copilot openspec context7-mcp markitdown; do
  if have "$t"; then p "$t: $(first_line "$t" --version)"; else f "$t not found"; fi
done
for pair in "codegraph:CODEGRAPH_MCP_COMMAND" "ikaro:IKARO_MCP_COMMAND"; do
  name="${pair%%:*}"; var="${pair##*:}"; cmd="${!var:-}"
  if [ -z "$cmd" ]; then w "$name: not configured in config/internal-tools.env"
  elif have "$cmd"; then p "$name: command '$cmd' found"
  else f "$name: command '$cmd' not found"; fi
done
if [ -z "${JIRA_MCP_COMMAND:-}" ]; then w "Jira MCP not configured (pending client answer: Cloud or Data Center)"; fi

section "Git and guardrails"
hp="$(git config --system core.hooksPath 2>/dev/null || true)"
if [ "$hp" = "$DEVENV_ROOT/git-hooks" ]; then p "System hooksPath: $hp"; else f "System core.hooksPath is '$hp' (expected $DEVENV_ROOT/git-hooks)"; fi
for h in pre-commit pre-merge-commit pre-push; do
  if [ -x "$DEVENV_ROOT/git-hooks/$h" ]; then p "Hook $h is executable"; else f "Hook $h missing or not executable"; fi
done
if [ -s /etc/dev-env/protected-branches ]; then p "Protected branches: $(head -n1 /etc/dev-env/protected-branches)"; else w "/etc/dev-env/protected-branches missing (built-in default is used)"; fi
if [ -n "$(git config --global user.name 2>/dev/null)" ] && [ -n "$(git config --global user.email 2>/dev/null)" ]; then
  p "Git identity: $(git config --global user.name) <$(git config --global user.email)>"
else w "Git identity not set: run 'dev-env identity'"; fi
if have gh; then
  if gh auth status -h "$GITHUB_HOST" >/dev/null 2>&1; then p "gh logged in to $GITHUB_HOST"; else w "gh not logged in: run 'dev-env login'"; fi
fi
if have glab; then
  case "$GITLAB_HOST" in
    *CHANGE_ME*) w "GITLAB_HOST is still a placeholder in config/kit.env" ;;
    *) if glab auth status -h "$GITLAB_HOST" >/dev/null 2>&1; then p "glab logged in to $GITLAB_HOST"; else w "glab not logged in to $GITLAB_HOST: run 'dev-env login'"; fi ;;
  esac
fi

section "Agent configuration"
if [ -L "$HOME/.copilot/copilot-instructions.md" ] && [ -e "$HOME/.copilot/copilot-instructions.md" ]; then p "Copilot CLI instructions linked"; else w "~/.copilot/copilot-instructions.md missing: run 'dev-env link-instructions'"; fi
if [ -L "$HOME/.copilot/instructions" ] && [ -d "$HOME/.copilot/instructions" ]; then p "VS Code user instructions linked"; else w "~/.copilot/instructions missing: run 'dev-env link-instructions'"; fi
nskills=$(find "$HOME/.copilot/skills" -maxdepth 1 -name 'openspec-*' -type d 2>/dev/null | wc -l)
if [ "$nskills" -gt 0 ]; then p "OpenSpec skills installed ($nskills)"; else w "No OpenSpec skills in ~/.copilot/skills: run 'dev-env refresh-skills'"; fi
for cfg in "$HOME/.copilot/mcp-config.json:mcpServers" "$HOME/.vscode-server/data/User/mcp.json:servers"; do
  file="${cfg%%:*}"; key="${cfg##*:}"
  if [ -s "$file" ] && jq -e ".${key} | length > 0" "$file" >/dev/null 2>&1; then
    p "MCP file OK: ${file/#$HOME/~} ($(jq -r ".${key} | keys | join(\",\")" "$file"))"
  else w "MCP file missing or empty: ${file/#$HOME/~}"; fi
done

section "Workspace layout"
case "$(readlink -f "$CODE_DIR")" in
  /mnt/*) f "CODE_DIR is on the Windows drive ($CODE_DIR): move it to the Linux filesystem" ;;
  *) p "Code directory on the Linux filesystem: $CODE_DIR" ;;
esac
if [ -d "$BACKLOG_DIR/.git" ]; then p "BACKLOG repository present"; else w "BACKLOG not cloned: run 'dev-env setup-repos'"; fi
if [ -d "$KNOWLEDGE_BASE_DIR/.git" ]; then p "KNOWLEDGE-BASE repository present"; else w "KNOWLEDGE-BASE not cloned: run 'dev-env setup-repos'"; fi
if [ -d "$BACKLOG_DIR/.git" ]; then
  if git -C "$BACKLOG_DIR" check-ignore -q repos 2>/dev/null; then p "BACKLOG/repos is git-ignored"; else w "BACKLOG/.gitignore does not ignore repos/"; fi
  if [ -d "$REPOS_DIR" ]; then p "Client repositories cloned: $(find "$REPOS_DIR" -maxdepth 2 -name .git 2>/dev/null | wc -l)"; fi
fi

section "Configuration"
for v in GITLAB_HOST BACKLOG_REPO_URL KNOWLEDGE_BASE_REPO_URL KIT_REPO_URL ARTIFACTORY_URL; do
  case "${!v}" in *CHANGE_ME*) w "$v is still a placeholder in config/kit.env" ;; *) p "$v set" ;; esac
done
if [ -f "$DEV_HOME/.m2/settings.xml" ]; then
  if grep -q CHANGE_ME "$DEV_HOME/.m2/settings.xml"; then w "~/.m2/settings.xml still has CHANGE_ME placeholders"; else p "~/.m2/settings.xml configured"; fi
else f "~/.m2/settings.xml missing"; fi

section "Connectivity"
probe "npm registry" https://registry.npmjs.org/
probe "GitHub" "https://$GITHUB_HOST"
case "$GITLAB_HOST" in *CHANGE_ME*) ;; *) probe "Client GitLab" "https://$GITLAB_HOST" ;; esac
case "$ARTIFACTORY_URL" in *CHANGE_ME*) ;; *) probe "Artifactory" "$ARTIFACTORY_URL" ;; esac
probe "Context7" https://mcp.context7.com/

if [ "$DEEP" -eq 1 ]; then
  section "Deep check: Maven through Artifactory"
  if mvn -B -q org.apache.maven.plugins:maven-dependency-plugin:2.10:get -Dartifact=junit:junit:4.12 >/tmp/dev-env-mvn-deep.log 2>&1; then
    p "Maven resolved junit:junit:4.12"
  else
    f "Maven could not resolve a test dependency (see /tmp/dev-env-mvn-deep.log)"
  fi
fi

printf '\nSummary: %s%d ok%s, %s%d warnings%s, %s%d failures%s\n' \
  "$(_c '1;32')" "$PASS" "$(_c 0)" "$(_c '1;33')" "$WARN" "$(_c 0)" "$(_c '1;31')" "$FAIL" "$(_c 0)"
[ "$FAIL" -eq 0 ]
