#!/usr/bin/env bash
# Provisions the WSL distro: runs every module in wsl/modules in order. Idempotent: safe to re-run.
#
# Usage (as root):  provision.sh [--only 10-base,20-java] [--skip 45-internal-tools] [--list]
# From Windows:     wsl -d Ubuntu-24.04 -u root --exec bash /opt/dev-env/wsl/provision.sh
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib/common.sh
. "$HERE/lib/common.sh"
load_config

ONLY=""
SKIP=""
while [ $# -gt 0 ]; do
  case "$1" in
    --only) ONLY="$2"; shift 2 ;;
    --skip) SKIP="$2"; shift 2 ;;
    --list) for m in "$HERE"/modules/[0-9]*.sh; do basename "$m" .sh; done; exit 0 ;;
    -h|--help) sed -n '2,6p' "${BASH_SOURCE[0]}"; exit 0 ;;
    *) die "Unknown option: $1" ;;
  esac
done

need_root
mkdir -p /var/log/dev-env
LOG="/var/log/dev-env/provision-$(date +%Y%m%d-%H%M%S).log"
exec > >(tee -a "$LOG") 2>&1

log "dev-env kit $(cat "$DEVENV_ROOT/VERSION" 2>/dev/null || echo '?') - provisioning (log: $LOG)"

in_list() { case ",$2," in *",$1,"*) return 0 ;; *) return 1 ;; esac; }

FAILED=""
for module in "$HERE"/modules/[0-9]*.sh; do
  name="$(basename "$module" .sh)"
  if [ -n "$ONLY" ] && ! in_list "$name" "$ONLY"; then continue; fi
  if [ -n "$SKIP" ] && in_list "$name" "$SKIP"; then log "Skipping $name"; continue; fi
  log "=== $name ==="
  # Each module is a separate bash process, so 'set -e' inside it is always effective.
  if DEVENV_ROOT="$DEVENV_ROOT" bash "$module"; then
    ok "$name finished"
  else
    FAILED="$name"
    err "$name failed. Fix the problem and re-run: sudo bash $HERE/provision.sh --only $name"
    break
  fi
done

if [ -n "$FAILED" ]; then
  err "Provisioning stopped at $FAILED. See $LOG"
  exit 1
fi

log "Running the doctor (as $DEV_USER)"
if id "$DEV_USER" >/dev/null 2>&1; then
  as_dev "DEVENV_ROOT='$DEVENV_ROOT' bash '$HERE/doctor.sh'" || true
else
  DEVENV_ROOT="$DEVENV_ROOT" bash "$HERE/doctor.sh" || true
fi
ok "Provisioning finished. Next: open a new Ubuntu terminal and follow docs/INSTALL.md (login, identity, setup-repos)."
