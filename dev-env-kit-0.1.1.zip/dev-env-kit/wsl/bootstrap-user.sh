#!/usr/bin/env bash
# Runs as root inside a fresh distro (called by windows/02-wsl-ubuntu.ps1).
# Creates the developer user, sudo policy and /etc/wsl.conf. Idempotent.
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/lib/common.sh"
load_config
need_root

mkdir -p /etc/dev-env /var/log/dev-env /var/lib/dev-env

# --- user ---------------------------------------------------------------------------------
if id "$DEV_USER" >/dev/null 2>&1; then
  ok "User '$DEV_USER' already exists"
else
  log "Creating user '$DEV_USER'"
  useradd -m -s /bin/bash "$DEV_USER"
  passwd -l "$DEV_USER" >/dev/null   # no password: WSL logs in as the default user directly
fi
for g in sudo adm plugdev netdev video; do
  if getent group "$g" >/dev/null 2>&1; then usermod -aG "$g" "$DEV_USER" || true; fi
done

# --- sudo policy --------------------------------------------------------------------------
SUDOERS=/etc/sudoers.d/90-dev-env
case "$DEV_SUDO" in
  nopasswd)
    echo "$DEV_USER ALL=(ALL) NOPASSWD:ALL" >"$SUDOERS.tmp"
    chmod 440 "$SUDOERS.tmp"
    if visudo -cf "$SUDOERS.tmp" >/dev/null; then mv "$SUDOERS.tmp" "$SUDOERS"; else rm -f "$SUDOERS.tmp"; die "Invalid sudoers entry"; fi
    ok "sudo without password enabled for $DEV_USER"
    ;;
  none)
    rm -f "$SUDOERS"
    gpasswd -d "$DEV_USER" sudo >/dev/null 2>&1 || true
    ok "sudo disabled for $DEV_USER (use 'wsl -u root' from Windows for privileged tasks)"
    ;;
  *) die "DEV_SUDO must be 'nopasswd' or 'none' (got '$DEV_SUDO')" ;;
esac

# --- /etc/wsl.conf ------------------------------------------------------------------------
if have python3; then
  DEV_USER="$DEV_USER" python3 - <<'PY'
import configparser, os
path = "/etc/wsl.conf"
cfg = configparser.ConfigParser()
cfg.optionxform = str
cfg.read(path)
for section in ("boot", "user"):
    if not cfg.has_section(section):
        cfg.add_section(section)
cfg["boot"]["systemd"] = "true"
cfg["user"]["default"] = os.environ["DEV_USER"]
with open(path, "w") as fh:
    cfg.write(fh, space_around_delimiters=False)
PY
else
  printf '[boot]\nsystemd=true\n\n[user]\ndefault=%s\n' "$DEV_USER" >/etc/wsl.conf
fi
ok "/etc/wsl.conf: default user = $DEV_USER (takes effect after 'wsl --terminate')"

# --- ownership of the installed kit ---------------------------------------------------------
chown -R "$DEV_USER:$DEV_USER" "$DEVENV_ROOT" 2>/dev/null || true
