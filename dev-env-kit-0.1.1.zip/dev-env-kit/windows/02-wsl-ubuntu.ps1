<#
.SYNOPSIS
  dev-env kit, Windows step 2: installs the Ubuntu distro, copies the kit into it and provisions it.

.DESCRIPTION
  Safe to run several times: an existing distro is kept; the kit is copied again and provisioning
  is re-run (this is also how a new version of the kit is applied from Windows).

.PARAMETER DistroName   WSL distro name (default Ubuntu-24.04).
.PARAMETER FromFile     Optional local image for locked-down networks: a .wsl file (wsl --install --from-file)
                        or a rootfs .tar/.tar.gz/.tar.xz (wsl --import).
.PARAMETER SkipProvision  Only install the distro, create the user and copy the kit.
#>
[CmdletBinding()]
param(
  [string]$DistroName = 'Ubuntu-24.04',
  [string]$FromFile = '',
  [switch]$SkipProvision
)

# 'Continue' on purpose: Windows PowerShell 5.1 turns any stderr text of native programs (wsl.exe)
# into terminating errors under 'Stop'. Failures are detected through exit codes and explicit throws.
$ErrorActionPreference = 'Continue'
$env:WSL_UTF8 = '1'   # wsl.exe prints UTF-8 instead of UTF-16 (readable output)
$KitRoot = Split-Path -Parent $PSScriptRoot

function Write-Step([string]$m) { Write-Host "[dev-env] $m" -ForegroundColor Cyan }
function Write-Ok([string]$m)   { Write-Host "[ ok ] $m" -ForegroundColor Green }
function Write-Warn([string]$m) { Write-Host "[warn] $m" -ForegroundColor Yellow }

function Get-WslDistros {
  # wsl.exe prints UTF-16; remove NUL characters so names compare correctly.
  $raw = & wsl.exe -l -q 2>$null
  if (-not $raw) { return @() }
  return @($raw | ForEach-Object { ($_ -replace "`0", '').Trim() } | Where-Object { $_ })
}

function Invoke-WslRoot([string[]]$Command) {
  # --exec avoids the distro default shell; only single quotes inside commands (Windows PowerShell 5.1 quoting).
  & wsl.exe -d $DistroName -u root --exec @Command
  if ($LASTEXITCODE -ne 0) { throw "WSL command failed (exit $LASTEXITCODE): $($Command -join ' ')" }
}

# --- 1. distro ------------------------------------------------------------------------------------
Write-Step "Looking for distro $DistroName"
$distros = Get-WslDistros
if ($distros -contains $DistroName) {
  Write-Ok "$DistroName is already installed (kept)"
} else {
  if ($FromFile) {
    if (-not (Test-Path $FromFile)) { throw "File not found: $FromFile" }
    if ($FromFile -like '*.wsl') {
      Write-Step "Installing from $FromFile"
      & wsl.exe --install --from-file $FromFile --no-launch
    } else {
      $dir = Join-Path $env:LOCALAPPDATA "WSL\$DistroName"
      New-Item -ItemType Directory -Force -Path $dir -ErrorAction Stop | Out-Null
      Write-Step "Importing $FromFile into $dir"
      & wsl.exe --import $DistroName $dir $FromFile --version 2
    }
  } else {
    Write-Step "Installing $DistroName (no first-run wizard)"
    & wsl.exe --install -d $DistroName --no-launch
    if ($LASTEXITCODE -ne 0) {
      Write-Warn 'Retrying with --web-download'
      & wsl.exe --install -d $DistroName --web-download --no-launch
    }
  }
  if ($LASTEXITCODE -ne 0) {
    throw "The distro could not be installed. See docs/TROUBLESHOOTING.md, section 'WSL install'. Alternative: download an Ubuntu 24.04 image and run with -FromFile."
  }
  $distros = Get-WslDistros
  if ($distros -notcontains $DistroName) {
    throw "Installed distro names: $($distros -join ', '). Re-run with -DistroName set to the right one."
  }
  Write-Ok "$DistroName installed"
}

Write-Step 'Checking root access in the distro'
Invoke-WslRoot @('true')
Write-Ok 'root access works'

# --- 2. copy the kit into the distro ------------------------------------------------------------
Write-Step 'Copying the kit into the distro (/opt/dev-env)'
$kitLinux = (& wsl.exe -d $DistroName -u root --exec wslpath -a $KitRoot | Out-String).Trim()
if (-not $kitLinux) { throw "Could not translate the kit path: $KitRoot" }

# Windows checkouts may use CRLF and lose exec bits: normalise after copying. Single quotes only.
$copy = @'
set -e
rm -rf /opt/dev-env.new
mkdir -p /opt/dev-env.new
cp -a 'KITPATH'/. /opt/dev-env.new/
find /opt/dev-env.new -type f -not -path '*/.git/*' -not -name '*.deb' -not -name '*.gz' -not -name '*.xz' -exec sed -i 's/\r$//' {} +
find /opt/dev-env.new -type f -not -path '*/.git/*' \( -name '*.sh' -o -path '*/wsl/bin/*' -o -path '*/git-hooks/*' \) -exec chmod +x {} +
if [ -d /opt/dev-env/vendor ]; then cp -an /opt/dev-env/vendor/. /opt/dev-env.new/vendor/ 2>/dev/null || true; fi
rm -rf /opt/dev-env.old
if [ -d /opt/dev-env ]; then mv /opt/dev-env /opt/dev-env.old; fi
mv /opt/dev-env.new /opt/dev-env
rm -rf /opt/dev-env.old
'@
$copy = $copy.Replace('KITPATH', $kitLinux)
Invoke-WslRoot @('bash', '-c', $copy)
Write-Ok 'Kit copied'

# --- 3. user, sudo policy and wsl.conf ----------------------------------------------------------
Write-Step 'Creating the developer user'
Invoke-WslRoot @('bash', '/opt/dev-env/wsl/bootstrap-user.sh')
& wsl.exe --terminate $DistroName
Write-Ok 'User ready (distro restarted so the default user applies)'

# --- 4. provisioning ------------------------------------------------------------------------------
if ($SkipProvision) {
  Write-Warn 'Provisioning skipped (-SkipProvision). Run it later: wsl -d Ubuntu-24.04 -u root --exec bash /opt/dev-env/wsl/provision.sh'
} else {
  Write-Step 'Provisioning (installs Java, Maven, Node, CLIs...). This takes several minutes.'
  & wsl.exe -d $DistroName -u root --exec bash /opt/dev-env/wsl/provision.sh
  if ($LASTEXITCODE -ne 0) {
    throw "Provisioning failed (exit $LASTEXITCODE). Read the log shown above (/var/log/dev-env), fix the cause and run this script again."
  }
  Write-Ok 'Provisioning finished'
}

Write-Host ''
Write-Host 'Next steps (inside Ubuntu, see docs/INSTALL.md - First use):' -ForegroundColor Green
Write-Host '  dev-env identity        # your git name and e-mail'
Write-Host '  dev-env login           # GitHub and GitLab (browser)'
Write-Host '  dev-env setup-repos     # clone BACKLOG and KNOWLEDGE-BASE'
Write-Host '  dev-env doctor          # verify everything'
exit 0
