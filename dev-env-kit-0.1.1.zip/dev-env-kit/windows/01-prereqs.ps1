<#
.SYNOPSIS
  dev-env kit, Windows step 1: checks prerequisites, enables WSL, writes .wslconfig, prepares VS Code.

.DESCRIPTION
  Safe to run several times. An elevated PowerShell is needed only when WSL is not installed yet.
  Exit codes: 0 = ok, 1 = problem found, 3 = restart required.

.PARAMETER MemoryGB          Memory limit for WSL (default: half of the RAM, between 4 and 16 GB).
.PARAMETER Processors        Processors for WSL (default: half of the logical processors, minimum 2).
.PARAMETER SwapGB            Swap size (default 4).
.PARAMETER MirroredNetworking  Use "networkingMode=mirrored" (Windows 11 22H2+). Helps with some VPNs; test it first.
.PARAMETER SkipVsCode        Do not touch VS Code.
.PARAMETER OverwriteWslConfig  Replace an existing %UserProfile%\.wslconfig (a backup is kept).
#>
[CmdletBinding()]
param(
  [int]$MemoryGB = 0,
  [int]$Processors = 0,
  [int]$SwapGB = 4,
  [switch]$MirroredNetworking,
  [switch]$SkipVsCode,
  [switch]$OverwriteWslConfig
)

# 'Continue' on purpose: Windows PowerShell 5.1 turns any stderr text of native programs (wsl.exe, code)
# into terminating errors under 'Stop'. Cmdlets that must not fail use -ErrorAction Stop explicitly.
$ErrorActionPreference = 'Continue'
$env:WSL_UTF8 = '1'   # wsl.exe prints UTF-8 instead of UTF-16 (readable output)
$KitRoot = Split-Path -Parent $PSScriptRoot
$script:Problems = 0

function Write-Step([string]$m) { Write-Host "[dev-env] $m" -ForegroundColor Cyan }
function Write-Ok([string]$m)   { Write-Host "[ ok ] $m" -ForegroundColor Green }
function Write-Warn([string]$m) { Write-Host "[warn] $m" -ForegroundColor Yellow }
function Write-Bad([string]$m)  { Write-Host "[FAIL] $m" -ForegroundColor Red; $script:Problems++ }

function Test-Admin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  return ([Security.Principal.WindowsPrincipal]$id).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Test-WslInstalled {
  # Windows PowerShell 5.1 turns native stderr into terminating errors under 'Stop'; relax it here.
  $previous = $ErrorActionPreference
  $ErrorActionPreference = 'Continue'
  try {
    & wsl.exe --version *> $null
    return ($LASTEXITCODE -eq 0)
  } catch {
    return $false
  } finally {
    $ErrorActionPreference = $previous
  }
}

# --- 1. Windows ---------------------------------------------------------------------------------
Write-Step 'Checking Windows'
$os = Get-CimInstance Win32_OperatingSystem
$build = [int]$os.BuildNumber
if ($build -ge 22000) { Write-Ok "Windows 11 (build $build) - $($os.Caption)" }
elseif ($build -ge 19044) { Write-Warn "Windows 10 build ${build}: WSL 2 works, but Windows 11 is the target of this kit." }
else { Write-Bad "Windows build $build is too old for WSL 2." }
if (-not [Environment]::Is64BitOperatingSystem) { Write-Bad 'A 64-bit Windows is required.' }

$cs = Get-CimInstance Win32_ComputerSystem
$ramGB = [math]::Round($cs.TotalPhysicalMemory / 1GB)
if ($ramGB -ge 16) { Write-Ok "RAM: $ramGB GB" } elseif ($ramGB -ge 8) { Write-Warn "RAM: $ramGB GB (16 GB or more is recommended)" } else { Write-Bad "RAM: $ramGB GB is too low." }

$sysDrive = $env:SystemDrive.TrimEnd(':')
$freeGB = [math]::Round((Get-PSDrive -Name $sysDrive).Free / 1GB)
if ($freeGB -ge 60) { Write-Ok "Free disk space on ${sysDrive}: $freeGB GB" } elseif ($freeGB -ge 30) { Write-Warn "Free disk space on ${sysDrive}: $freeGB GB (60 GB or more is recommended)" } else { Write-Bad "Free disk space on ${sysDrive}: $freeGB GB is too low." }

$virt = $cs.HypervisorPresent
if (-not $virt) {
  $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
  $virt = [bool]$cpu.VirtualizationFirmwareEnabled
}
if ($virt) { Write-Ok 'Virtualization is available' } else { Write-Bad 'Virtualization is disabled. Enable it in the BIOS/UEFI (Intel VT-x / AMD-V / SVM).' }

# --- 2. WSL -------------------------------------------------------------------------------------
Write-Step 'Checking WSL'
if (Test-WslInstalled) {
  Write-Ok 'WSL is installed'
  try {
    & wsl.exe --update *> $null
    Write-Ok 'WSL is up to date (or the update is not available from this network)'
  } catch {
    Write-Warn 'Could not run "wsl --update". Continue; update WSL later if something fails.'
  }
} else {
  if ($script:Problems -gt 0) { exit 1 }
  if (-not (Test-Admin)) {
    Write-Bad 'WSL is not installed. Run this script from an elevated PowerShell (Run as administrator) with YOUR user account, or ask IT to run "wsl --install --no-distribution".'
    exit 1
  }
  Write-Step 'Installing WSL (no distribution yet)'
  & wsl.exe --install --no-distribution
  Write-Warn 'WSL was installed. Restart Windows, then run INSTALL-WINDOWS.cmd again.'
  exit 3
}

# --- 3. .wslconfig ------------------------------------------------------------------------------
Write-Step 'Checking %UserProfile%\.wslconfig'
$cfgPath = Join-Path $env:USERPROFILE '.wslconfig'
$mem = $MemoryGB
if ($mem -le 0) { $mem = [int][math]::Max(4, [math]::Min(16, [math]::Floor($ramGB / 2))) }
$cpus = $Processors
if ($cpus -le 0) { $cpus = [int][math]::Max(2, [math]::Floor([Environment]::ProcessorCount / 2)) }
$lines = @(
  '# Written by the dev-env kit. Run "wsl --shutdown" after changing it.',
  '[wsl2]',
  "memory=${mem}GB",
  "processors=$cpus",
  "swap=${SwapGB}GB"
)
if ($MirroredNetworking) { $lines += 'networkingMode=mirrored' }

if ((Test-Path $cfgPath) -and -not $OverwriteWslConfig) {
  Write-Ok '.wslconfig already exists (kept). Suggested content if WSL runs out of memory:'
  $lines | ForEach-Object { Write-Host "         $_" }
} else {
  if (Test-Path $cfgPath) {
    $backup = "$cfgPath.bak-$(Get-Date -Format yyyyMMddHHmmss)"
    Copy-Item $cfgPath $backup -ErrorAction Stop
    Write-Ok "Backup saved: $backup"
  }
  Set-Content -Path $cfgPath -Value $lines -Encoding ASCII -ErrorAction Stop
  Write-Ok ".wslconfig written: memory=${mem}GB processors=$cpus swap=${SwapGB}GB"
}

# --- 4. VS Code ---------------------------------------------------------------------------------
if (-not $SkipVsCode) {
  Write-Step 'Checking VS Code'
  $codeExe = $null
  $cmd = Get-Command code -ErrorAction SilentlyContinue
  if ($cmd) { $codeExe = $cmd.Source }
  if (-not $codeExe) {
    foreach ($p in @("$env:LOCALAPPDATA\Programs\Microsoft VS Code\bin\code.cmd", "$env:ProgramFiles\Microsoft VS Code\bin\code.cmd")) {
      if (Test-Path $p) { $codeExe = $p; break }
    }
  }
  if (-not $codeExe) {
    Write-Bad 'VS Code was not found. Install it from the company software catalog, then run this script again.'
  } else {
    Write-Ok "VS Code found: $codeExe"
    $extFile = Join-Path $KitRoot 'config\vscode-extensions-windows.txt'
    if (Test-Path $extFile) {
      Get-Content $extFile | ForEach-Object {
        $id = ($_ -replace '#.*$', '').Trim()
        if ($id) {
          try {
            & $codeExe --install-extension $id *> $null
            if ($LASTEXITCODE -eq 0) { Write-Ok "Extension: $id" } else { Write-Warn "Extension $id could not be installed (blocked or not found). Install it from the Extensions view." }
          } catch {
            Write-Warn "Extension $id could not be installed: $($_.Exception.Message)"
          }
        }
      }
    }

    # Disable remote control of Copilot CLI sessions (company decision). Never rewrites an existing file.
    $settingsPath = Join-Path $env:APPDATA 'Code\User\settings.json'
    $key = 'github.copilot.chat.cli.remote.enabled'
    if (-not (Test-Path $settingsPath)) {
      New-Item -ItemType Directory -Force -Path (Split-Path $settingsPath) -ErrorAction Stop | Out-Null
      Set-Content -Path $settingsPath -Value @('{', "  `"$key`": false", '}') -Encoding ASCII -ErrorAction Stop
      Write-Ok "VS Code user settings created with $key = false"
    } elseif ((Get-Content $settingsPath -Raw) -match [regex]::Escape($key)) {
      Write-Ok "VS Code setting $key is present (check that it is false)"
    } else {
      Write-Warn "Add this line to $settingsPath (not edited automatically):  `"$key`": false,"
    }
  }
}

# --- result -------------------------------------------------------------------------------------
Write-Host ''
if ($script:Problems -gt 0) {
  Write-Host "Step 1 finished with $($script:Problems) problem(s). Fix them and run again." -ForegroundColor Red
  exit 1
}
Write-Host 'Step 1 finished without problems.' -ForegroundColor Green
exit 0
