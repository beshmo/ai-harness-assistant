# Brief for <repo> - @@KEY@@ (@@SLUG@@)

Copy this file to `<repo>.md`. It is the only input the agent working in that repository needs:
keep it self-contained. Paste it (or point the agent to it) when you start the OpenSpec proposal,
and keep a copy inside the repository's OpenSpec change as `umbrella-brief.md`.

- Umbrella change: BACKLOG/changes/@@KEY@@-@@SLUG@@
- OpenSpec change name to use: `@@KEY@@-@@SLUG@@`
- Branch: `feature/@@KEY@@-@@SLUG@@` (from DEVELOPMENT)

## What this repository must do
Concrete behaviour changes, in this repository only.

## Contracts
Interfaces this repository provides or consumes, with versions.

## Constraints and order
Depends on: (other repos / artifact versions). Must be deployed before/after: ...

## Out of scope
-

## Manual test scenario for this repository
-
