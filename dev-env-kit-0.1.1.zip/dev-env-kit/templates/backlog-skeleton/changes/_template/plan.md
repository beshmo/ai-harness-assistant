# @@KEY@@ - @@SLUG@@: plan

Same identifier everywhere: OpenSpec change `@@KEY@@-@@SLUG@@` in each repository, branch `feature/@@KEY@@-@@SLUG@@`,
commit prefix `@@KEY@@:`, merge request title.

A library change reaches its consumers only through Artifactory (published by Jenkins). Record the order
and the artifact version each consumer must use. For local tests use `mvn install` in the provider.

| # | Repo | Depends on | Change in the repo | Artifact / version | Status | MR |
|---|---|---|---|---|---|---|
| 1 |  |  |  |  | todo |  |

Status values: `todo` -> `proposed` -> `reviewed` -> `applied` -> `mr-open` -> `merged` -> `deployed-dev` -> `deployed-test`.

Update the table at every milestone.
