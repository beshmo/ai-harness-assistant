# @@KEY@@ - @@SLUG@@: analysis

- Jira: @@KEY@@
- Created: @@DATE@@
- Status: draft | reviewed | approved

## 1. Context and goal
What is requested and why (link the Jira issue).

## 2. Evidence
How the impacted code was found (Ikaro / codegraph queries, files, call chains).

## 3. Impacted repositories
| Repo | Why it is impacted | Type (provider / consumer / standalone) |
|---|---|---|
|  |  |  |

## 4. Contracts between repositories
Interfaces, shared libraries, configuration or data formats that cross repositories.
The provider repository's spec owns each contract; consumers reference it.
Prefer backward-compatible changes first (deployment is manual and per repository).

## 5. Risks and open questions
-

## 6. Review
Reviewer, date, decisions taken.
