# @@KEY@@ - @@SLUG@@: acceptance and deployment

## Deployment order
1.

## Manual test scenario (cross-repository)
Steps and expected results on DEV, then TEST.

## Rollback
What to redeploy and in which order.

## Results
| Date | Environment | Who | Result |
|---|---|---|---|
|  |  |  |  |
