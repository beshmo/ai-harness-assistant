---
description: Shared working rules for every repository maintained from BACKLOG
applyTo: "**"
---

# Shared working rules

These rules apply to every repository maintained for the client. Follow them even when a task
does not mention them.

## Context

- We maintain and evolve a content-management platform and portals (OpenText WEM 16.7 and
  OpenText Portal 16.7). Work is corrective and evolutive maintenance.
- Keep code compatible with **Java 8** (no Java 9+ APIs or syntax, no `var`, no modules).
- Build with **Maven 3.3.3**. Dependencies come from the client's Artifactory (read-only access).
  Do not change dependency versions or repositories unless the task requires it.
- Deployment and testing on DEV/TEST are manual and done by people.

## Git rules (hard rules)

- Never commit, merge or push to `DEVELOPMENT` or `MASTER`. Work on `feature/<KEY>-<slug>`,
  `fix/<KEY>-<slug>` or `chore/<slug>` branches. Changes reach `DEVELOPMENT`/`MASTER` only through merge requests.
- Never use `--no-verify`, never force-push, never rewrite published history.
- Do not push or open merge requests unless the developer asks you to.
- Commit messages start with the Jira key: `PROJ-123: short description`.

## Workflow

- **Evolutive changes** use OpenSpec: propose, human review, apply, human review. Do not start
  implementing before the proposal is reviewed.
- **Small corrective fixes** that do not change specified behaviour may skip OpenSpec. If you are not
  sure whether behaviour changes, ask.
- **Changes that touch several repositories** have an umbrella change in `BACKLOG/changes/<KEY>-<slug>/`.
  Work from the brief of the repository you are in (`repos/<repo>.md`) and keep the same KEY in the
  OpenSpec change name, branch and commits.
- Keep changes small and reviewable. Ask before large refactors or deleting files.

## Knowledge sources

- Use the **Ikaro** documentation search for OpenText WEM/Portal APIs and client documentation before
  guessing. If the documentation does not confirm an API, say so instead of inventing it.
- Use **context7** for documentation of third-party libraries.
- Use **codegraph** for call graphs, usages and impact analysis.
- Jira access is read-only.

## Safety

- Never put secrets in code, config files or commits.
- Do not run deployment commands and do not connect to the client's platform over SSH.
- The repositories have very few tests. When you change behaviour, add or update tests for the code you
  touch when practical, and say what you could not verify.

<!-- Decide and uncomment: language used for specs, commit messages and chat with developers. -->
