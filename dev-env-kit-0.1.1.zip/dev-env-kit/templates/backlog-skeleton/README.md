# BACKLOG

Main repository for analysis, review, audit and cross-repository (umbrella) changes of the client platform.

| Path | Purpose |
|---|---|
| `repos/` | Client repositories cloned here for implementation (git-ignored, managed with `bk-clone-all`) |
| `repos.tsv` | List of client repositories (name, URL, notes) |
| `changes/` | Umbrella changes: `changes/<KEY>-<slug>/` (see `changes/_template`) |
| `workspaces/` | Generated multi-root `.code-workspace` files (`bk-workspace`) |
| `shared/instructions/` | Shared rules loaded by Copilot (CLI and VS Code) on every developer machine |

Daily commands: `bk-sync`, `bk-new-branch`, `bk-umbrella-new`, `bk-workspace`, `bk-onboard-repo`, `dev-env doctor`.
See the dev-env kit documentation (`docs/DAILY-USE.md`).

Rules that apply here too: never commit to `DEVELOPMENT` or `MASTER`; use work branches and merge requests.
