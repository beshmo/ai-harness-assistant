# Changelog

## 0.1.1 - 2026-11-02
- Fix: `windows/01-prereqs.ps1` did not parse in Windows PowerShell ("Variable reference is not valid. ':' was not followed by a valid variable name character", line 59: `"$build: ..."` must be `"${build}: ..."`).
- Windows scripts: `$ErrorActionPreference = 'Continue'` (Windows PowerShell 5.1 turns stderr text of native programs into terminating errors under 'Stop'); `WSL_UTF8=1` so `wsl.exe` output is readable; explicit `-ErrorAction Stop` on file cmdlets.
- Tests: static check for `$var:` hazards and non-ASCII characters in `.ps1` files; optional real parse with PowerShell when available (`tests/parse-ps.ps1`).
- The PowerShell scripts were parsed with the PowerShell parser (7.0.3 on Linux) and executed against a fake `wsl.exe` and mocked Windows cmdlets.

## 0.1.0 - 2026-11-02
- First version of the kit.
