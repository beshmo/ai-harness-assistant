@echo off
rem dev-env kit - Windows entry point (double-click or run from a terminal).
rem Step 1: prerequisites (WSL, .wslconfig, VS Code extensions). Step 2: Ubuntu + provisioning.
setlocal
set "KIT=%~dp0"
echo ============================================================
echo  dev-env kit - Windows setup
echo ============================================================

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%KIT%windows\01-prereqs.ps1"
if errorlevel 3 (
  echo.
  echo A restart is required. Restart Windows and run this file again.
  pause
  exit /b 3
)
if errorlevel 1 (
  echo.
  echo Step 1 failed. Read the messages above, fix the problem and run this file again.
  pause
  exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%KIT%windows\02-wsl-ubuntu.ps1" %*
if errorlevel 1 (
  echo.
  echo Step 2 failed. Read the messages above. It is safe to run this file again.
  pause
  exit /b 1
)

echo.
echo Done. Open "Ubuntu-24.04" from Windows Terminal and continue with docs\INSTALL.md (section "First use").
pause
exit /b 0
