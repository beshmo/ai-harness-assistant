# Corporate CA certificates (optional)

If the company network inspects TLS traffic (a proxy re-signs HTTPS), tools inside WSL fail with
certificate errors (`curl: (60)`, `PKIX path building failed`, `UNABLE_TO_GET_ISSUER_CERT_LOCALLY`).

Drop the corporate root/intermediate certificates here as `*.crt` or `*.pem` (PEM format, ask IT or
export them from the Windows certificate store). `wsl/modules/05-certs.sh` installs them into the
Ubuntu trust store, which also feeds the Java 8 truststore, and exports the variables that Node.js
and Python need.

Leave this folder without certificates if you do not need them.
