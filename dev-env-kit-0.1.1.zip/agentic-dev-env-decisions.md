# Agentic development environment: decisions and notes

Status: decisions closed except Jira and proxy; kit v0.1.0 built, pending validation on the company laptop. Updated 2026-11-02. Source: design sessions with the project owner. The implementation plan is in `implementation-plan.md`.

## 1. Decisions taken

| Area | Decision |
|---|---|
| Parallel sessions | Native VS Code Copilot CLI sessions (worktree isolation). Orca and other orchestrators discarded. Fallback: `bk-new-branch -w` (plain `git worktree`). |
| Host | Windows 11 Pro corporate laptops, one WSL2 Ubuntu 24.04 distro per laptop, generic Linux user `developer`. |
| VS Code access | VS Code on Windows connected to WSL (Remote - WSL). Confirmed. The UNC path is used only for Explorer and Office documents. |
| Installation | `dev-env-kit`: Windows installer + idempotent WSL provisioning + manual, so developers of any level can set up WSL, VS Code and the toolchain. |
| Agent tooling (WSL) | Copilot CLI, codegraph, Ikaro, context7, OpenSpec, JDK 8, Maven 3.3.3, git, gh, glab, markitdown, pandoc + TeX Live, Node, Python. |
| Git hosting | Main repo, docs and kit on the company GitHub. Client repos on the client GitLab (`glab`). |
| Authentication | Browser login for `gh` / `glab`. No tokens configured by hand. |
| Artifactory | Shared read-only user in a common `settings.xml`. No other secrets in Maven. |
| Jira | Read-only MCP. |
| SSH to client platform | Postponed. Deployment stays manual. |
| SonarQube | Out of scope for now. |
| SDD | OpenSpec for evolutive work. Small corrective fixes that do not change specified behaviour may skip OpenSpec. |
| Multi-repo model | No git submodules. Client repos are cloned under `BACKLOG/repos` (git-ignored). Branches and worktrees are per repo. OpenSpec in every repo; each repo has its own specs, committed with the repo. |
| OpenSpec footprint | Only the `openspec/` folder is committed in client repos. OpenSpec skills are installed at user level (`~/.copilot/skills`). |
| Protected branches | `DEVELOPMENT` (integrated DEV deployments) and `MASTER` (goes to TEST/PRO); both exist in every client repo. Changes reach them only through controlled merge requests. Branches for work can be created freely. Enforced locally with git hooks (GitLab protection is not configurable). |
| Cross-repo changes | Umbrella change in BACKLOG, then repo-by-repo implementation with OpenSpec (section 3.5). Approved. |
| Knowledge base | `KNOWLEDGE-BASE` is a separate repo on the company GitHub (documentation and Ikaro index). The owner copies documents, indexes and publishes the index. Ikaro searches against the remote index. |
| Reviews | Human review at analysis, at the OpenSpec proposal, after apply (assisted by an agent), then manual deployment and testing. |
| Tests | Almost none today. Created incrementally. |
| Legacy knowledge | Specs, refactors and docs are generated incrementally per repo. OpenText WEM / Portal 16.7 javadoc and PDFs go into the knowledge base. |
| Client contract | The company AI contract allows opening client repos. context7 is allowed. |
| Onboarding repos | Incremental: `bk-onboard-repo` the first time a repo is touched. |

## 2. Directory layout

```
/home/developer/code/BACKLOG                 main repo (company GitHub): analysis, review, audit, umbrella changes
/home/developer/code/BACKLOG/repos           client repos cloned here (listed in BACKLOG/.gitignore, manifest repos.tsv)
/home/developer/code/BACKLOG/workspaces      generated .code-workspace files (see code-workspace-guide.md)
/home/developer/code/BACKLOG/shared          shared instructions
/home/developer/code/worktrees               worktrees created with bk-new-branch -w (outside BACKLOG/repos)
/home/developer/docs/KNOWLEDGE-BASE          KNOWLEDGE-BASE repo: documentation (pdf, md, ...) and Ikaro index
```

Notes:
- Tools that honour `.gitignore` skip `BACKLOG/repos` when started at the BACKLOG root. Work inside each repo, or use a multi-root workspace.
- Worktree location for native VS Code sessions is decided by VS Code. Verify it in the pilot and keep worktrees out of `BACKLOG/repos`.

## 3. Notes to keep in mind

### 3.1 Duplicate indexes when opening WSL folders from Windows
Opening the folder through the Windows path (`\\wsl.localhost\Ubuntu\home\developer\...`) in a Windows-side VS Code makes extensions run on the Windows side. Consequences:
- codegraph and Ikaro indexes can exist twice (Windows and WSL).
- Toolchain mismatch (Windows vs WSL JDK, Maven, git).
- Slower git and file watching over the 9P/UNC share.
- Copilot CLI sessions would likely run on the Windows side instead of in WSL.

Decision: always use Remote - WSL (`code .` from WSL, or "Connect to WSL"). Documented in the kit manual and troubleshooting guide. (The doctor cannot detect a UNC window from inside WSL; it checks that the code folder is on the Linux filesystem.)

### 3.2 Git hooks as a guardrail (no GitLab branch protection available)
A system-wide `core.hooksPath` (set by the kit) covers every clone and worktree with no per-repo setup:

```bash
git config --system core.hooksPath /opt/dev-env/git-hooks
```

- `pre-commit`: refuses commits on protected branches (detached HEAD allowed so rebases work).
- `pre-merge-commit`: refuses local merge commits on protected branches.
- `pre-push`: refuses creating, updating or deleting protected remote branches (also catches fast-forward merges done locally).
- Protected pattern: `PROTECTED_BRANCHES_REGEX` env var, else `/etc/dev-env/protected-branches`, else default `^(DEVELOPMENT|MASTER)$` (case-sensitive).
- Covered by the kit's automated tests (commit on `DEVELOPMENT`/`MASTER` blocked, merge commit blocked, push and delete blocked, feature branch commit and push allowed).
- Limits: advisory only. `--no-verify` bypasses them, and VS Code worktree sessions run with approvals bypassed. Shared instructions say never to use `--no-verify` or to push to protected branches.
- Browser login still stores an OAuth token in WSL for `gh` / `glab`, so push permission exists for anything running as that user.
- Work branches: `feature/<KEY>-<slug>` or `fix/<KEY>-<slug>`, created from `DEVELOPMENT`, merge request into `DEVELOPMENT`. Promotion to `MASTER` is also by merge request.

### 3.3 Shared instructions, skills and MCP (verified with Copilot CLI 1.0.105)
- `copilot skill list` shows the 6 OpenSpec skills from `~/.copilot/skills` as *Personal skills*.
- `copilot instruction list` shows `~/.copilot/copilot-instructions.md` (a symlink into the shared instructions) as *Personal instructions*.
- `copilot mcp list` reads `~/.copilot/mcp-config.json` (format: `mcpServers` with `type: local`, `command`, `args`, `env`, `tools`).
- `COPILOT_CUSTOM_INSTRUCTIONS_DIRS` did not pick up a root-level `*.instructions.md` in the tested version: the kit does not use it.
- `/add-dir <path>` (and `--add-dir`) grants file access and loads that directory's `.github/skills` and `.github/agents`; it does not load instruction files.
- VS Code chat reads user instructions from `~/.copilot/instructions` and MCP servers from a user `mcp.json`. The kit writes `~/.vscode-server/data/User/mcp.json`; **this path and the instructions folder are still to be verified in a WSL window**. Fallback: *MCP: Open Remote User Configuration*.
- Single source of truth: `BACKLOG/shared/instructions/` (versioned); the kit links it to both locations. Until BACKLOG exists, the kit's template is linked.

### 3.4 OpenSpec files and the client repositories
- Git worktrees contain only tracked files. The `openspec/` folder must therefore be committed in each repo for native worktree sessions to see it.
- `openspec init --tools none` creates only `openspec/` (config.yaml, specs/, changes/archive/). Verified.
- `.github/` stays out of client repos: skills are generated once (`openspec init --tools github-copilot` in a scratch repo with `delivery=skills`) and copied to `~/.copilot/skills`. The skills are generic (no project paths).
- Copilot CLI does not read `.github/prompts/*.prompt.md`, so the OpenSpec slash commands are not available in the CLI. With skills: `/openspec-propose`, `/openspec-apply-change`, `/openspec-archive-change`, `/openspec-explore`.
- Adding `openspec/` to a client repo requires a merge request into `DEVELOPMENT`.
- OpenSpec anonymous telemetry is switched off by the kit (`OPENSPEC_TELEMETRY=0` and `telemetry.enabled=false`).

### 3.5 Umbrella change convention (approved)
Used whenever an evolutive touches several repos. Analysis happens in BACKLOG; implementation happens repo by repo with OpenSpec. Template and helper: `bk-umbrella-new KEY slug`.

```
BACKLOG/changes/PROJ-123-slug/
  analysis.md       context, evidence, impacted repos, risks, open questions
  plan.md           table: repo | order | depends on | change in the repo | status | MR
  repos/<repo>.md   self-contained brief for that repo
  acceptance.md     cross-repo manual test and deployment order
```

1. One identifier: Jira key + slug names the BACKLOG folder, the OpenSpec change in each repo, the branch, the commit prefix and the MR title.
2. One brief per repo: the agent working in a repo receives only its brief, copied into `openspec/changes/<id>/` so it travels with the repo and its worktrees. The full analysis is reachable with `/add-dir`.
3. Order and artifacts: a library change reaches consumers only through Artifactory (published by Jenkins). `plan.md` records the order and the artifact version consumed. Use `mvn install` for local tests.
4. Contracts: the provider repo's spec owns the contract; consumers reference it. Backward-compatible changes first, because deployment is manual and per repo.
5. Status and gates: `plan.md` is updated at each milestone (proposed, reviewed, applied, MR, deployed). The analysis is reviewed in BACKLOG (pull request) before entering any repo.

### 3.6 Kit design notes
- The Windows installer copies the kit into the distro (`/opt/dev-env`), converts CRLF to LF and restores executable bits (tested on a CRLF copy), creates the `developer` user and `/etc/wsl.conf`, then runs `wsl/provision.sh`.
- `DEV_SUDO=nopasswd` by default (simplicity); `none` disables sudo for the developer user.
- Config variables are not exported to child processes: the Copilot CLI reads `COPILOT_CLI_VERSION`, so the kit uses `COPILOT_PACKAGE_VERSION`.
- npm global packages go to `/usr/local` (on every PATH), markitdown through pipx in `/opt/pipx`. Node.js comes from the official tarball (checksum verified).
- MCP files of the kit are merged, so servers added by hand are preserved; files are mode 600.

## 4. Open items

| # | Item | Status |
|---|---|---|
| 1 | Jira at the client: Cloud or Data Center (decides which MCP server) | Pending a talk with the client. Jira module of the kit stays optional until known. |
| 2 | Corporate proxy / TLS inspection inside WSL | Unknown. Works on the owner's laptop. The kit supports corporate CA certificates, `vendor/` offline cache and a doctor with hints. |
| 3 | Single maintainer of the knowledge base and the Ikaro index | Accepted for now. Automate refresh later. |
| 4 | Install commands and MCP commands of codegraph and Ikaro | The owner fills `config/internal-tools.env`; empty entries are skipped. |
| 5 | How the owner logs in to the client GitLab (browser OAuth vs personal access token) | To confirm during validation; `dev-env login` runs `glab auth login`. |
| 6 | Validation of the Windows scripts and the unverified items on the company laptop | Next step: kit `docs/VALIDATION-CHECKLIST.md`. |

Closed: Windows access mode, protected branches, branches present in all repos, KNOWLEDGE-BASE nature, OpenSpec footprint, umbrella convention, incremental repo onboarding.
